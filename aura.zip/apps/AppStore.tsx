import React from 'react';
import { OS_NAME, APPS } from '../constants';
import type { AppDefinition, AppCategory } from '../types';

const AppCard: React.FC<{ app: AppDefinition }> = ({ app }) => (
    <div className="bg-mac-gray-light p-4 rounded-xl flex items-center space-x-4 border border-gray-200/80">
        <div className="w-16 h-16 flex-shrink-0">{app.icon}</div>
        <div className="flex-grow">
            <h3 className="text-md font-bold text-mac-text">{app.name}</h3>
            <p className="text-xs text-mac-text-secondary mt-0.5">{app.description}</p>
        </div>
         <button 
            className="bg-blue-100 hover:bg-blue-200 text-mac-blue font-bold py-1 px-4 rounded-full text-sm disabled:opacity-50"
            disabled // This button is non-functional for now
            aria-label={`Get ${app.name} (disabled)`}
        >
            GET
        </button>
    </div>
);

const AppCategorySection: React.FC<{ title: string, apps: AppDefinition[] }> = ({ title, apps }) => (
    <div className="mb-8">
        <h2 className="text-2xl font-bold text-mac-text mb-4 pb-2 border-b border-gray-200">{title}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {apps.map(app => (
                <AppCard key={app.id} app={app} />
            ))}
        </div>
    </div>
);


export const AppStoreApp: React.FC = () => {
    const categories: AppCategory[] = ['System', 'Productivity', 'Entertainment'];
    
    const categorizedApps = categories.reduce((acc, category) => {
        const appsInCategory = APPS.filter(app => app.category === category);
        if (appsInCategory.length > 0) {
            acc[category] = appsInCategory;
        }
        return acc;
    }, {} as Record<string, AppDefinition[]>);

    return (
        <div className="w-full h-full bg-mac-gray-light text-mac-text p-6 overflow-y-auto">
            <header className="mb-8">
                <h1 className="text-4xl font-extrabold text-mac-text">Discover Apps</h1>
                <p className="text-mac-text-secondary mt-1">Curated for {OS_NAME}</p>
            </header>
            
            {Object.entries(categorizedApps).map(([category, apps]) => (
                 <AppCategorySection key={category} title={category} apps={apps} />
            ))}
        </div>
    );
};