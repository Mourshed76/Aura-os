import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, Chat } from '@google/genai';

interface Message {
    id: number;
    sender: 'user' | 'ai';
    text: string;
}

const API_KEY = process.env.API_KEY;

export const AuraApp: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([
        { id: 0, sender: 'ai', text: "I'm Aura. How can I help you today?" }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [chat, setChat] = useState<Chat | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!API_KEY) {
            setError("API key is not available.");
            return;
        }
        try {
            const ai = new GoogleGenAI({ apiKey: API_KEY });
            const chatInstance = ai.chats.create({
                model: 'gemini-2.5-flash',
                config: {
                    systemInstruction: 'You are Aura, a helpful and friendly AI assistant integrated into the Aura operating system. You are running inside a web-based simulation of an OS. Keep your responses concise and creative.',
                },
            });
            setChat(chatInstance);
        } catch (e: any) {
            setError(`Failed to initialize AI: ${e.message}`);
        }
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = useCallback(async () => {
        if (!input.trim() || isLoading || !chat) return;

        const userMessage: Message = { id: Date.now(), sender: 'user', text: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);
        setError(null);
        
        const aiMessageId = Date.now() + 1;
        
        try {
            const responseStream = await chat.sendMessageStream({ message: input });

            let fullResponse = '';
            let firstChunk = true;
            for await (const chunk of responseStream) {
                fullResponse += chunk.text;
                 if (firstChunk) {
                    setMessages(prev => [...prev, { id: aiMessageId, sender: 'ai', text: fullResponse }]);
                    firstChunk = false;
                } else {
                    setMessages(prev => prev.map(msg => 
                        msg.id === aiMessageId ? { ...msg, text: fullResponse } : msg
                    ));
                }
            }
             setMessages(prev => prev.map(msg => 
                    msg.id === aiMessageId ? { ...msg, text: fullResponse.trim() } : msg
            ));


        } catch (e: any) {
            const errorMessage = `Error: ${e.message || 'An unknown error occurred.'}`;
            setError(errorMessage);
            setMessages(prev => [...prev, { id: aiMessageId, sender: 'ai', text: `I'm having some trouble right now. Please try again later.` }]);
        } finally {
            setIsLoading(false);
        }
    }, [input, isLoading, chat]);

    return (
        <div className="w-full h-full flex flex-col bg-mac-gray text-mac-text">
            <div className="flex-grow p-4 overflow-y-auto space-y-3">
                {messages.map((message) => (
                    <div key={message.id} className={`flex items-end gap-2 ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs md:max-w-md px-3 py-2 rounded-2xl ${message.sender === 'user' ? 'bg-mac-blue text-white' : 'bg-gray-200 text-mac-text'}`}>
                           {message.text}
                        </div>
                    </div>
                ))}
                 {isLoading && messages[messages.length-1].sender === 'user' && (
                    <div className="flex items-end gap-2 justify-start">
                        <div className="max-w-xs md:max-w-md px-3 py-2 rounded-2xl bg-gray-200">
                           <div className="flex space-x-1">
                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0s' }}></span>
                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.15s' }}></span>
                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.3s' }}></span>
                           </div>
                        </div>
                    </div>
                 )}
                <div ref={messagesEndRef} />
            </div>
            {error && <div className="p-1 text-center bg-red-500/20 text-red-800 text-xs">{error}</div>}
            <div className="p-2 border-t border-gray-300">
                <div className="flex items-center space-x-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="Message"
                        className="flex-grow bg-gray-200/80 text-mac-text px-4 py-2 rounded-full focus:outline-none focus:ring-2 focus:ring-mac-blue/50 border border-gray-300"
                        disabled={isLoading || !chat}
                    />
                    <button
                        onClick={handleSend}
                        disabled={isLoading || !input.trim() || !chat}
                        className="disabled:opacity-50 disabled:cursor-not-allowed text-mac-blue font-semibold"
                    >
                         Send
                    </button>
                </div>
            </div>
        </div>
    );
};
