import React, { useState, useMemo } from 'react';

export const PhotosApp: React.FC = () => {
    const [seed, setSeed] = useState(() => Math.random().toString(36).substring(7));
    const imageUrl = useMemo(() => `https://picsum.photos/seed/${seed}/1200/800`, [seed]);

    const refreshImage = () => {
        setSeed(Math.random().toString(36).substring(7));
    };
    
    const bgPattern = `
      linear-gradient(45deg, #ccc 25%, transparent 25%), 
      linear-gradient(-45deg, #ccc 25%, transparent 25%),
      linear-gradient(45deg, transparent 75%, #ccc 75%),
      linear-gradient(-45deg, transparent 75%, #ccc 75%)`;
    
    return (
        <div 
          className="w-full h-full flex flex-col items-center justify-center bg-gray-100"
          style={{ 
            backgroundColor: '#e5e5e5',
            backgroundImage: bgPattern,
            backgroundSize: '20px 20px',
          }}
        >
            <div className="flex-grow w-full h-full p-4 flex items-center justify-center">
                <img src={imageUrl} alt="Randomly generated" className="max-w-full max-h-full object-contain shadow-2xl rounded-lg border-2 border-white" />
            </div>
            <div className="flex-shrink-0 p-2 text-center">
                <button
                    onClick={refreshImage}
                    className="px-4 py-1.5 bg-gray-200/80 hover:bg-gray-300/80 backdrop-blur-sm text-mac-text font-medium rounded-md transition-colors border border-black/10 text-sm"
                >
                    Next Photo
                </button>
            </div>
        </div>
    );
};
