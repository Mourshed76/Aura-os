import React from 'react';

export const FinderApp: React.FC = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-center text-center p-8 text-mac-text-secondary">
             <div className="text-6xl mb-4">🖥️</div>
            <h1 className="text-2xl font-semibold text-mac-text">Welcome to WebOS</h1>
            <p className="mt-2 max-w-md">
                This is a web-based operating system inspired by macOS.
                You can open apps from the Dock or Launchpad, move windows, and interact with the system.
            </p>
        </div>
    );
};
