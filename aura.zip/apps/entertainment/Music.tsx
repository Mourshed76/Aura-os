import React from 'react';
import type { AppProps } from '../../types';

export const MusicApp: React.FC<AppProps> = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-center text-center p-8 bg-gray-900 text-white">
            <div className="text-6xl mb-4">🎵</div>
            <h1 className="text-2xl font-semibold">Music</h1>
            <p className="text-gray-400 mt-2">Coming Soon</p>
        </div>
    );
};