
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import type { AppProps } from '../../types';
import { useSettings } from '../../context/SettingsContext';

type Album = 'all' | 'private';

interface PrivatePhoto {
    seed: string;
    addedAt: number;
}

const usePrivatePhotos = () => {
    const [photos, setPhotos] = useState<PrivatePhoto[]>(() => {
        try {
            const saved = localStorage.getItem('aura-privatePhotos');
            return saved ? JSON.parse(saved) : [];
        } catch {
            return [];
        }
    });

    useEffect(() => {
        localStorage.setItem('aura-privatePhotos', JSON.stringify(photos));
    }, [photos]);

    const addPhoto = (seed: string) => {
        const newPhoto: PrivatePhoto = { seed, addedAt: Date.now() };
        setPhotos(prev => [newPhoto, ...prev]);
    };

    const removePhoto = (seed: string) => {
        setPhotos(prev => prev.filter(p => p.seed !== seed));
    };
    
    return { privatePhotos: photos, addPrivatePhoto: addPhoto, removePrivatePhoto: removePhoto };
};


export const PhotosApp: React.FC<AppProps> = () => {
    const { setWallpaper, privateAlbumPassword } = useSettings();
    const { privatePhotos, addPrivatePhoto, removePrivatePhoto } = usePrivatePhotos();

    const [currentAlbum, setCurrentAlbum] = useState<Album>('all');
    const [publicSeed, setPublicSeed] = useState(() => Math.random().toString(36).substring(7));
    const [privatePhotoIndex, setPrivatePhotoIndex] = useState(0);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [passwordInput, setPasswordInput] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const [isPrivateUnlocked, setIsPrivateUnlocked] = useState(false);

    const [feedback, setFeedback] = useState('');

    const currentSeed = useMemo(() => {
        if (currentAlbum === 'private') {
            return privatePhotos[privatePhotoIndex]?.seed || null;
        }
        return publicSeed;
    }, [currentAlbum, publicSeed, privatePhotos, privatePhotoIndex]);

    const imageUrl = useMemo(() => currentSeed ? `https://picsum.photos/seed/${currentSeed}/1200/800` : null, [currentSeed]);

    const handleNextPhoto = () => {
        if (currentAlbum === 'all') {
            setPublicSeed(Math.random().toString(36).substring(7));
        } else if (isPrivateUnlocked && privatePhotos.length > 0) {
            setPrivatePhotoIndex(prev => (prev + 1) % privatePhotos.length);
        }
    };

    const handleSetWallpaper = () => {
        if (!imageUrl) return;
        setWallpaper(imageUrl);
        setFeedback('Wallpaper set!');
        setTimeout(() => setFeedback(''), 2000);
    };

    const handleDownload = async () => {
        if (!imageUrl) return;
        try {
            const response = await fetch(imageUrl);
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${currentSeed}.jpg`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            a.remove();
        } catch (error) {
            console.error('Download failed:', error);
            setFeedback('Download failed.');
            setTimeout(() => setFeedback(''), 2000);
        }
    };
    
    const handlePasswordSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (passwordInput === privateAlbumPassword) {
            setIsPrivateUnlocked(true);
            setIsModalOpen(false);
            setPasswordError('');
            setPasswordInput('');
            setCurrentAlbum('private');
        } else {
            setPasswordError('Incorrect password. Please try again.');
        }
    };
    
    const handleAlbumChange = (album: Album) => {
        if (album === 'private' && !isPrivateUnlocked) {
            setIsModalOpen(true);
        } else {
            setCurrentAlbum(album);
        }
    };

    const toggleAddToPrivate = () => {
        if (!currentSeed) return;
        if(privatePhotos.some(p => p.seed === currentSeed)){
            removePrivatePhoto(currentSeed);
        } else {
            addPrivatePhoto(currentSeed);
        }
    };

    const bgPattern = `
      linear-gradient(45deg, #ddd 25%, transparent 25%), 
      linear-gradient(-45deg, #ddd 25%, transparent 25%),
      linear-gradient(45deg, transparent 75%, #ddd 75%),
      linear-gradient(-45deg, transparent 75%, #ddd 75%)`;

    return (
        <div className="w-full h-full flex bg-mac-gray">
            {/* Sidebar */}
            <aside className="w-48 h-full bg-mac-gray-header/60 p-3 shrink-0 border-r border-black/10">
                <h2 className="text-xs font-bold text-gray-500 uppercase px-2 mb-2">Library</h2>
                <div className="space-y-1">
                    <SidebarItem icon="🖼️" label="All Photos" isActive={currentAlbum === 'all'} onClick={() => handleAlbumChange('all')} />
                    <SidebarItem icon="🔒" label="Private" isActive={currentAlbum === 'private'} onClick={() => handleAlbumChange('private')} />
                </div>
            </aside>
            
            {/* Main Content */}
            <main className="flex-grow flex flex-col" style={{ backgroundColor: '#e5e5e5', backgroundImage: bgPattern, backgroundSize: '20px 20px' }}>
                <div className="flex-grow w-full p-4 flex items-center justify-center relative">
                    {feedback && <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-black/60 text-white px-4 py-2 rounded-full text-sm z-10">{feedback}</div>}
                    {imageUrl ? (
                        <img src={imageUrl} alt="Photo" className="max-w-full max-h-full object-contain shadow-2xl rounded-lg border-2 border-white" />
                    ) : (
                        <div className="text-center text-gray-500">
                            <p className="text-2xl mb-2">📂</p>
                            <p>This album is empty.</p>
                        </div>
                    )}
                </div>
                <div className="flex-shrink-0 p-2 text-center bg-gray-200/50 backdrop-blur-sm border-t border-black/10 flex justify-center items-center space-x-3">
                    <ActionButton onClick={handleDownload} disabled={!imageUrl} label="Download" icon="⬇️" />
                    <ActionButton onClick={handleSetWallpaper} disabled={!imageUrl} label="Set as Wallpaper" icon="🌄" />
                    <ActionButton onClick={handleNextPhoto} disabled={currentAlbum === 'private' && privatePhotos.length < 2} label="Next Photo" icon="➡️" />
                     {currentAlbum === 'all' && (
                        <ActionButton 
                            onClick={toggleAddToPrivate}
                            disabled={!imageUrl} 
                            label={privatePhotos.some(p => p.seed === currentSeed) ? 'Remove from Private' : 'Add to Private'} 
                            icon={privatePhotos.some(p => p.seed === currentSeed) ? '✅' : '🔒'}
                        />
                    )}
                </div>
            </main>
            
            {/* Password Modal */}
            {isModalOpen && (
                <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-20">
                    <form onSubmit={handlePasswordSubmit} className="bg-white/80 backdrop-blur-lg p-8 rounded-2xl shadow-xl text-center border border-white/20">
                        <h2 className="text-lg font-bold text-mac-text mb-2">Private Album Locked</h2>
                        <p className="text-sm text-mac-text-secondary mb-4">Enter the password to view this album.</p>
                        <input
                            type="password"
                            value={passwordInput}
                            onChange={(e) => setPasswordInput(e.target.value)}
                            className="w-full px-3 py-2 bg-white/50 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-mac-blue"
                            autoFocus
                        />
                        {passwordError && <p className="text-red-500 text-xs mt-2">{passwordError}</p>}
                        <div className="mt-6 flex justify-end space-x-3">
                            <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-1.5 bg-gray-200 hover:bg-gray-300 text-mac-text font-medium rounded-md transition-colors text-sm">Cancel</button>
                            <button type="submit" className="px-4 py-1.5 bg-mac-blue hover:bg-mac-blue/90 text-white font-medium rounded-md transition-colors text-sm">Unlock</button>
                        </div>
                    </form>
                </div>
            )}
        </div>
    );
};

const SidebarItem: React.FC<{ icon: string; label: string; isActive: boolean; onClick: () => void }> = ({ icon, label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`flex items-center w-full text-left px-3 py-2 rounded-lg transition-colors duration-150 ${
            isActive ? 'bg-mac-blue/20 text-mac-blue' : 'hover:bg-gray-200/50'
        }`}
    >
        <span className="text-md mr-3">{icon}</span>
        <span className="font-medium text-sm">{label}</span>
    </button>
);

const ActionButton: React.FC<{ onClick: () => void; disabled?: boolean; label: string, icon: string }> = ({ onClick, disabled, label, icon }) => (
    <button
        onClick={onClick}
        disabled={disabled}
        className="px-4 py-1.5 bg-white/60 hover:bg-white/90 backdrop-blur-sm text-mac-text font-medium rounded-md transition-colors border border-black/10 text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
        aria-label={label}
    >
        <span className="text-md">{icon}</span>
        {label}
    </button>
);
