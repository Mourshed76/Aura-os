

import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { AppProps } from '../../types';

const PADDLE_WIDTH = 100;
const PADDLE_HEIGHT = 15;
const BALL_RADIUS = 8;
const GAME_WIDTH = 560;
const GAME_HEIGHT = 400;

const BRICK_ROWS = 5;
const BRICK_COLS = 8;
const BRICK_WIDTH = 60;
const BRICK_HEIGHT = 20;
const BRICK_PADDING = 10;
const BRICK_OFFSET_TOP = 30;
const BRICK_OFFSET_LEFT = 30;

type Brick = { x: number; y: number; status: 1 | 0, color: string };
type GameState = 'waiting' | 'playing' | 'gameOver' | 'win';

const BRICK_COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6'];

const createBricks = (): Brick[] => {
    const bricks: Brick[] = [];
    for (let c = 0; c < BRICK_COLS; c++) {
        for (let r = 0; r < BRICK_ROWS; r++) {
            bricks.push({
                x: c * (BRICK_WIDTH + BRICK_PADDING) + BRICK_OFFSET_LEFT,
                y: r * (BRICK_HEIGHT + BRICK_PADDING) + BRICK_OFFSET_TOP,
                status: 1,
                color: BRICK_COLORS[r % BRICK_COLORS.length],
            });
        }
    }
    return bricks;
};

export const BrickBreakerApp: React.FC<AppProps> = () => {
    const [paddleX, setPaddleX] = useState(GAME_WIDTH / 2 - PADDLE_WIDTH / 2);
    const [ball, setBall] = useState({ x: GAME_WIDTH / 2, y: GAME_HEIGHT - 50, dx: 3, dy: -3 });
    const [bricks, setBricks] = useState<Brick[]>(() => createBricks());
    const [score, setScore] = useState(0);
    const [lives, setLives] = useState(3);
    const [gameState, setGameState] = useState<GameState>('waiting');
    const gameRef = useRef<HTMLDivElement>(null);
    const animationFrameId = useRef<number>();


    const resetLevel = useCallback((startLives: number) => {
        setBall({ x: GAME_WIDTH / 2, y: GAME_HEIGHT - 50, dx: 3, dy: -3 });
        setPaddleX(GAME_WIDTH / 2 - PADDLE_WIDTH / 2);
        setLives(startLives);
        setGameState('waiting');
    }, []);

    const handleStartGame = () => {
        if(gameState === 'waiting') {
            setGameState('playing');
        }
    };

    const handleNewGame = () => {
        setScore(0);
        setBricks(createBricks());
        resetLevel(3);
    };

    const gameLoop = useCallback(() => {
        if (gameState !== 'playing') return;

        // Ball movement
        const newBall = { ...ball };
        newBall.x += newBall.dx;
        newBall.y += newBall.dy;

        // Wall collision
        if (newBall.x + BALL_RADIUS > GAME_WIDTH || newBall.x - BALL_RADIUS < 0) {
            newBall.dx = -newBall.dx;
        }
        if (newBall.y - BALL_RADIUS < 0) {
            newBall.dy = -newBall.dy;
        } else if (newBall.y + BALL_RADIUS > GAME_HEIGHT) {
            setLives(l => l - 1);
            if (lives - 1 <= 0) {
                setGameState('gameOver');
            } else {
                resetLevel(lives - 1);
            }
            return;
        }

        // Paddle collision
        if (
            newBall.y + BALL_RADIUS > GAME_HEIGHT - PADDLE_HEIGHT &&
            newBall.dy > 0 &&
            newBall.x + BALL_RADIUS > paddleX &&
            newBall.x - BALL_RADIUS < paddleX + PADDLE_WIDTH
        ) {
            const hitPoint = newBall.x - (paddleX + PADDLE_WIDTH / 2);
            const normalizedHitPoint = hitPoint / (PADDLE_WIDTH / 2);
            const bounceAngle = normalizedHitPoint * 5; // max change in dx
            
            newBall.dy = -newBall.dy;
            newBall.dx = bounceAngle;
        }
        
        // Brick collision
        const newBricks = [...bricks];
        let allBricksBroken = true;
        for (const brick of newBricks) {
            if(brick.status === 1) {
                allBricksBroken = false;
                 if (
                    newBall.x + BALL_RADIUS > brick.x &&
                    newBall.x - BALL_RADIUS < brick.x + BRICK_WIDTH &&
                    newBall.y + BALL_RADIUS > brick.y &&
                    newBall.y - BALL_RADIUS < brick.y + BRICK_HEIGHT
                ) {
                    newBall.dy = -newBall.dy; // Simplified bounce for now
                    brick.status = 0;
                    setScore(s => s + 10);
                }
            }
        }

        if(allBricksBroken) {
            setGameState('win');
        }

        setBricks(newBricks);
        setBall(newBall);
        animationFrameId.current = requestAnimationFrame(gameLoop);
    }, [ball, bricks, paddleX, lives, gameState, resetLevel]);

    useEffect(() => {
        if (gameState === 'playing') {
            animationFrameId.current = requestAnimationFrame(gameLoop);
        } else {
            if(animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
        }
        return () => {
            if(animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
        };
    }, [gameState, gameLoop]);

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        if (gameRef.current) {
            const rect = gameRef.current.getBoundingClientRect();
            const newX = e.clientX - rect.left - PADDLE_WIDTH / 2;
            setPaddleX(Math.max(0, Math.min(newX, GAME_WIDTH - PADDLE_WIDTH)));
             if (gameState === 'waiting') {
                setBall(b => ({ ...b, x: newX + PADDLE_WIDTH / 2 }));
            }
        }
    };
    
    return (
        <div className="w-full h-full bg-gray-900 flex flex-col items-center justify-center text-white select-none">
            <div className="w-full max-w-[560px] flex justify-between items-center p-2 text-xl font-bold">
                <span>Score: {score}</span>
                <span>Lives: {lives}</span>
            </div>
            <div
                ref={gameRef}
                className="relative bg-black border-2 border-gray-600 cursor-none"
                style={{ width: GAME_WIDTH, height: GAME_HEIGHT }}
                onMouseMove={handleMouseMove}
                onClick={handleStartGame}
            >
                {/* Paddle */}
                <div className="absolute bg-blue-400 rounded-sm" style={{ left: paddleX, bottom: 0, width: PADDLE_WIDTH, height: PADDLE_HEIGHT }} />
                
                {/* Ball */}
                <div className="absolute bg-white rounded-full" style={{ left: ball.x - BALL_RADIUS, top: ball.y - BALL_RADIUS, width: BALL_RADIUS * 2, height: BALL_RADIUS * 2 }} />

                {/* Bricks */}
                {bricks.map((brick, index) =>
                    brick.status === 1 ? (
                        <div key={index} className="absolute rounded-sm" style={{ left: brick.x, top: brick.y, width: BRICK_WIDTH, height: BRICK_HEIGHT, backgroundColor: brick.color }} />
                    ) : null
                )}

                {/* Game State Overlay */}
                {gameState !== 'playing' && (
                    <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-center">
                        {gameState === 'waiting' && <h2 className="text-3xl font-bold">Click to Start</h2>}
                        {gameState === 'gameOver' && <h2 className="text-4xl font-bold text-red-500">Game Over</h2>}
                        {gameState === 'win' && <h2 className="text-4xl font-bold text-green-500">You Win!</h2>}
                        
                        {(gameState === 'gameOver' || gameState === 'win') && (
                            <button onClick={handleNewGame} className="mt-6 px-6 py-2 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600 transition-colors">
                                Play Again
                            </button>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};
