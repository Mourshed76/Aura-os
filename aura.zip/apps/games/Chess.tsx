import React, { useState, useMemo, useEffect } from 'react';
import type { AppProps } from '../../types';
import { Chess } from 'chess.js';
import { Chessboard } from 'react-chessboard';

export const ChessApp: React.FC<AppProps> = ({ windowId }) => {
    const [game, setGame] = useState(new Chess());
    // Force re-render on game state change
    const [fen, setFen] = useState(game.fen());

    const gameStatus = useMemo(() => {
        let status = '';
        const turn = game.turn() === 'w' ? 'White' : 'Black';
        
        if (game.isCheckmate()) {
            status = `Checkmate! ${turn === 'White' ? 'Black' : 'White'} wins.`;
        } else if (game.isDraw()) {
            status = 'Draw!';
        } else {
            status = `${turn}'s turn`;
            if (game.isCheck()) {
                status += ' - Check!';
            }
        }
        return status;
    }, [fen]);

    function onDrop(sourceSquare: string, targetSquare: string) {
        const gameCopy = new Chess(game.fen());
        try {
            const move = gameCopy.move({
                from: sourceSquare,
                to: targetSquare,
                promotion: 'q', // auto-promote to queen for simplicity
            });
            
            if (move === null) return false; // illegal move
            
            setGame(gameCopy);
            setFen(gameCopy.fen());
            return true;

        } catch (error) {
            console.log("Invalid move:", error);
            return false;
        }
    }
    
    const newGame = () => {
        const newGameInstance = new Chess();
        setGame(newGameInstance);
        setFen(newGameInstance.fen());
    };

    const undoMove = () => {
        const gameCopy = new Chess(game.fen());
        gameCopy.undo();
        setGame(gameCopy);
        setFen(gameCopy.fen());
    };

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-gray-800 text-white p-4 select-none">
            <div className="flex-grow flex items-center justify-center w-full">
                 <Chessboard 
                    id={windowId}
                    position={fen}
                    onPieceDrop={onDrop}
                    boardWidth={360}
                    customBoardStyle={{
                        borderRadius: '4px',
                        boxShadow: '0 5px 15px rgba(0, 0, 0, 0.5)',
                    }}
                    customDarkSquareStyle={{ backgroundColor: '#769656' }}
                    customLightSquareStyle={{ backgroundColor: '#eeeed2' }}
                 />
            </div>
            <div className="flex-shrink-0 w-full max-w-[360px] pt-4 text-center">
                <p className="text-lg font-semibold mb-3">{gameStatus}</p>
                <div className="flex justify-center space-x-4">
                     <button onClick={undoMove} className="px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded-md transition-colors">Undo Move</button>
                    <button onClick={newGame} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-md transition-colors">New Game</button>
                </div>
            </div>
        </div>
    );
};
