

import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { AppProps } from '../../types';

const PADDLE_HEIGHT = 80;
const PADDLE_WIDTH = 10;
const BALL_SIZE = 10;
const GAME_WIDTH = 600;
const GAME_HEIGHT = 400;
const WINNING_SCORE = 5;

type GameState = 'menu' | 'playing' | 'gameOver';

export const PongApp: React.FC<AppProps> = () => {
    const [playerY, setPlayerY] = useState(GAME_HEIGHT / 2 - PADDLE_HEIGHT / 2);
    const [aiY, setAiY] = useState(GAME_HEIGHT / 2 - PADDLE_HEIGHT / 2);
    const [ball, setBall] = useState({ x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2, dx: 0, dy: 0 });
    const [score, setScore] = useState({ player: 0, ai: 0 });
    const [gameState, setGameState] = useState<GameState>('menu');
    const [winner, setWinner] = useState<'Player' | 'AI' | null>(null);
    const gameRef = useRef<HTMLDivElement>(null);
    const animationFrameId = useRef<number>();

    const resetBall = useCallback((winner: 'player' | 'ai' | null = null) => {
        const direction = winner === null
            ? (Math.random() > 0.5 ? 1 : -1)
            : (winner === 'player' ? 1 : -1);
        
        setBall({
            x: GAME_WIDTH / 2,
            y: GAME_HEIGHT / 2,
            dx: 5 * direction,
            dy: Math.random() > 0.5 ? 3 : -3,
        });
    }, []);

    const gameLoop = useCallback(() => {
        if(gameState !== 'playing') return;

        // --- Ball Movement ---
        setBall(prevBall => {
            let newBall = { ...prevBall };
            newBall.x += newBall.dx;
            newBall.y += newBall.dy;

            // Wall collision (top/bottom)
            if (newBall.y <= 0 || newBall.y >= GAME_HEIGHT - BALL_SIZE) {
                newBall.dy *= -1;
            }

            // Paddle collision
            // Player
            if (newBall.dx < 0 && newBall.x <= PADDLE_WIDTH && newBall.x > 0 && newBall.y + BALL_SIZE >= playerY && newBall.y <= playerY + PADDLE_HEIGHT) {
                newBall.dx *= -1.1; // Increase speed slightly on hit
                newBall.dy += (newBall.y - (playerY + PADDLE_HEIGHT/2))/PADDLE_HEIGHT * 5; // Add spin
            }
            // AI
            if (newBall.dx > 0 && newBall.x >= GAME_WIDTH - PADDLE_WIDTH - BALL_SIZE && newBall.x < GAME_WIDTH - BALL_SIZE && newBall.y + BALL_SIZE >= aiY && newBall.y <= aiY + PADDLE_HEIGHT) {
                newBall.dx *= -1.1;
            }

            // --- Scoring ---
            if (newBall.x < 0) { // AI scores
                setScore(s => ({ ...s, ai: s.ai + 1 }));
                resetBall('ai');
            } else if (newBall.x > GAME_WIDTH) { // Player scores
                setScore(s => ({ ...s, player: s.player + 1 }));
                resetBall('player');
            }

            // Limit ball speed
            newBall.dx = Math.min(Math.max(newBall.dx, -15), 15);
            
            return newBall;
        });

        // --- AI Movement ---
        setAiY(prevAiY => {
            const aiCenter = prevAiY + PADDLE_HEIGHT / 2;
            const targetY = ball.y;
            const diff = targetY - aiCenter;
            const speed = 4.5; // AI speed
            if (Math.abs(diff) > speed) {
                const move = Math.sign(diff) * speed;
                return Math.max(0, Math.min(prevAiY + move, GAME_HEIGHT - PADDLE_HEIGHT));
            }
            return prevAiY;
        });

        animationFrameId.current = requestAnimationFrame(gameLoop);
    }, [gameState, ball.y, playerY, aiY, resetBall]);

    useEffect(() =>