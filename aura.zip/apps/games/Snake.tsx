import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { AppProps } from '../../types';

const BOARD_SIZE = 20;
const CELL_SIZE = 20; // in pixels
const INITIAL_SPEED = 200; // ms
const MIN_SPEED = 60; // ms
const SPEED_INCREMENT = 5; // ms faster per point

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
type Position = { x: number; y: number };

const getRandomPosition = (snake: Position[] = []): Position => {
    let position: Position;
    do {
        position = {
            x: Math.floor(Math.random() * BOARD_SIZE),
            y: Math.floor(Math.random() * BOARD_SIZE),
        };
    } while (snake.some(segment => segment.x === position.x && segment.y === position.y));
    return position;
};

export const SnakeApp: React.FC<AppProps> = () => {
    const [snake, setSnake] = useState<Position[]>([{ x: 10, y: 10 }]);
    const [food, setFood] = useState<Position>(() => getRandomPosition(snake));
    const [direction, setDirection] = useState<Direction>('RIGHT');
    const [isGameOver, setIsGameOver] = useState(false);
    const [score, setScore] = useState(0);
    const [highScore, setHighScore] = useState(() => Number(localStorage.getItem('snakeHighScore')) || 0);

    const gameLoopTimeoutRef = useRef<number | null>(null);

    const handleKeyDown = useCallback((e: KeyboardEvent) => {
        e.preventDefault();
        switch (e.key) {
            case 'ArrowUp':
                setDirection(dir => dir !== 'DOWN' ? 'UP' : dir);
                break;
            case 'ArrowDown':
                setDirection(dir => dir !== 'UP' ? 'DOWN' : dir);
                break;
            case 'ArrowLeft':
                setDirection(dir => dir !== 'RIGHT' ? 'LEFT' : dir);
                break;
            case 'ArrowRight':
                setDirection(dir => dir !== 'LEFT' ? 'RIGHT' : dir);
                break;
        }
    }, []);

    useEffect(() => {
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [handleKeyDown]);
    
    const gameLoop = useCallback(() => {
        if (isGameOver) return;
        
        const newSnake = [...snake];
        const head = { ...newSnake[0] };

        switch (direction) {
            case 'UP': head.y -= 1; break;
            case 'DOWN': head.y += 1; break;
            case 'LEFT': head.x -= 1; break;
            case 'RIGHT': head.x += 1; break;
        }

        if (head.x < 0 || head.x >= BOARD_SIZE || head.y < 0 || head.y >= BOARD_SIZE ||
            newSnake.some(segment => segment.x === head.x && segment.y === head.y)) {
            setIsGameOver(true);
            if (score > highScore) {
                setHighScore(score);
                localStorage.setItem('snakeHighScore', String(score));
            }
            return;
        }
        
        newSnake.unshift(head);

        if (head.x === food.x && head.y === food.y) {
            setScore(prev => prev + 1);
            setFood(getRandomPosition(newSnake));
        } else {
            newSnake.pop();
        }

        setSnake(newSnake);
    }, [snake, direction, food, isGameOver, score, highScore]);
    
    useEffect(() => {
        if (isGameOver) {
            if (gameLoopTimeoutRef.current) clearTimeout(gameLoopTimeoutRef.current);
            return;
        }

        const gameSpeed = Math.max(MIN_SPEED, INITIAL_SPEED - score * SPEED_INCREMENT);
        
        gameLoopTimeoutRef.current = window.setTimeout(gameLoop, gameSpeed);

        return () => {
            if (gameLoopTimeoutRef.current) clearTimeout(gameLoopTimeoutRef.current);
        };
    }, [gameLoop, isGameOver, score]);

    const handleRestart = () => {
        const initialSnake = [{ x: 10, y: 10 }];
        setSnake(initialSnake);
        setFood(getRandomPosition(initialSnake));
        setDirection('RIGHT');
        setIsGameOver(false);
        setScore(0);
    };

    return (
        <div className="w-full h-full bg-gray-800 text-white flex flex-col items-center justify-center p-4 select-none">
            <div className="flex justify-between w-full max-w-[400px] mb-4">
                <h1 className="text-xl font-bold">Snake</h1>
                <p className="text-xl">Score: {score} <span className="text-gray-400">| High: {highScore}</span></p>
            </div>
            <div
                className="bg-gray-900 border-2 border-gray-700 relative"
                style={{ width: BOARD_SIZE * CELL_SIZE, height: BOARD_SIZE * CELL_SIZE }}
            >
                {snake.map((segment, index) => (
                    <div
                        key={index}
                        className={`absolute ${index === 0 ? 'bg-green-400' : 'bg-green-600'} rounded-sm`}
                        style={{ left: segment.x * CELL_SIZE, top: segment.y * CELL_SIZE, width: CELL_SIZE, height: CELL_SIZE }}
                    />
                ))}
                <div
                    className="absolute bg-red-500 rounded-full"
                    style={{ left: food.x * CELL_SIZE, top: food.y * CELL_SIZE, width: CELL_SIZE, height: CELL_SIZE }}
                />
                 {isGameOver && (
                    <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-center">
                        <h2 className="text-3xl font-bold text-red-500">Game Over</h2>
                        <p className="text-lg mt-1">Your score: {score}</p>
                        <p className="text-md text-gray-300">High score: {highScore}</p>
                        <button
                            onClick={handleRestart}
                            className="mt-4 px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded"
                        >
                            Restart
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};
