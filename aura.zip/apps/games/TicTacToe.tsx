
import React, { useState, useEffect } from 'react';
import type { AppProps } from '../../types';

type Player = 'X' | 'O';
type SquareValue = Player | null;
type GameMode = 'menu' | 'pvp' | 'pva';

const calculateWinner = (squares: SquareValue[]): { winner: Player; line: number[] } | null => {
  const lines = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6],
  ];
  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return { winner: squares[a] as Player, line: lines[i] };
    }
  }
  return null;
};

const minimax = (newBoard: SquareValue[], player: Player): { score: number, index?: number } => {
  const availableSpots = newBoard.map((s, i) => s === null ? i : null).filter(s => s !== null);

  const winnerInfo = calculateWinner(newBoard);
  if (winnerInfo) {
    if (winnerInfo.winner === 'O') return { score: 10 };
    if (winnerInfo.winner === 'X') return { score: -10 };
  } else if (availableSpots.length === 0) {
    return { score: 0 };
  }

  const moves: { index: number; score: number }[] = [];
  for (let i = 0; i < availableSpots.length; i++) {
    const index = availableSpots[i] as number;
    const move: { index: number; score: number } = { index, score: 0 };
    newBoard[index] = player;

    if (player === 'O') {
      const result = minimax(newBoard, 'X');
      move.score = result.score;
    } else {
      const result = minimax(newBoard, 'O');
      move.score = result.score;
    }
    newBoard[index] = null;
    moves.push(move);
  }

  let bestMove = 0;
  if (player === 'O') {
    let bestScore = -10000;
    for (let i = 0; i < moves.length; i++) {
      if (moves[i].score > bestScore) {
        bestScore = moves[i].score;
        bestMove = i;
      }
    }
  } else {
    let bestScore = 10000;
    for (let i = 0; i < moves.length; i++) {
      if (moves[i].score < bestScore) {
        bestScore = moves[i].score;
        bestMove = i;
      }
    }
  }
  return moves[bestMove];
};

const Square: React.FC<{ value: SquareValue; onClick: () => void; isWinnerSquare: boolean }> = ({ value, onClick, isWinnerSquare }) => (
  <button
    className={`w-24 h-24 bg-gray-200 border-2 border-gray-400 flex items-center justify-center text-4xl font-bold transition-colors
      ${isWinnerSquare ? 'bg-yellow-400' : ''}
      ${value === 'X' ? 'text-blue-600' : 'text-red-600'}`}
    onClick={onClick}
    disabled={!!value}
  >
    {value}
  </button>
);


export const TicTacToeApp: React.FC<AppProps> = () => {
    const [board, setBoard] = useState<SquareValue[]>(Array(9).fill(null));
    const [xIsNext, setXIsNext] = useState(true);
    const [gameMode, setGameMode] = useState<GameMode>('menu');

    const winnerInfo = calculateWinner(board);
    const winner = winnerInfo?.winner;
    const isDraw = !winner && board.every(square => square !== null);

    const makeAiMove = (currentBoard: SquareValue[]) => {
      const availableSpots = currentBoard.map((s, i) => s === null ? i : null).filter(s => s !== null);
      if (availableSpots.length === 0) return;
    
      const bestMove = minimax(currentBoard, 'O');
      const bestMoveIndex = bestMove.index;
    
      setTimeout(() => {
        const newBoard = currentBoard.slice();
        if(bestMoveIndex !== undefined && newBoard[bestMoveIndex] === null) {
          newBoard[bestMoveIndex] = 'O';
          setBoard(newBoard);
          setXIsNext(true);
        }
      }, 500); // AI "thinks" for a moment
    };

    const handleClick = (i: number) => {
        if (winner || board[i]) return;
        
        const newBoard = board.slice();
        newBoard[i] = xIsNext ? 'X' : 'O';
        setBoard(newBoard);
        setXIsNext(!xIsNext);
    };

    useEffect(() => {
        if (gameMode === 'pva' && !xIsNext && !winner && !isDraw) {
            makeAiMove(board);
        }
    }, [xIsNext, gameMode, board, winner, isDraw]);

    const handleRestart = (mode: GameMode) => {
        setBoard(Array(9).fill(null));
        setXIsNext(true);
        setGameMode(mode);
    };

    let status;
    if (winner) {
        status = 'Winner: ' + winner;
    } else if (isDraw) {
        status = 'Draw!';
    } else {
        status = 'Next player: ' + (xIsNext ? 'X' : 'O');
    }

    if (gameMode === 'menu') {
        return (
            <div className="w-full h-full bg-gray-100 flex flex-col items-center justify-center p-4">
                <h1 className="text-4xl font-bold mb-8">Tic-Tac-Toe</h1>
                <div className="flex flex-col space-y-4">
                     <button onClick={() => handleRestart('pvp')} className="px-8 py-3 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600 transition-colors text-lg">
                        Player vs. Player
                    </button>
                     <button onClick={() => handleRestart('pva')} className="px-8 py-3 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition-colors text-lg">
                        Player vs. AI
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="w-full h-full bg-gray-100 flex flex-col items-center justify-center p-4">
            <h1 className="text-3xl font-bold mb-4">{status}</h1>
            <div className="grid grid-cols-3 gap-1">
                {board.map((square, i) => (
                    <Square key={i} value={square} onClick={() => handleClick(i)} isWinnerSquare={winnerInfo?.line.includes(i) || false} />
                ))}
            </div>
            <button onClick={() => setGameMode('menu')} className="mt-6 px-6 py-2 bg-gray-500 text-white font-semibold rounded-lg hover:bg-gray-600 transition-colors">
                Back to Menu
            </button>
        </div>
    );
};
