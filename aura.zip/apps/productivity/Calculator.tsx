import React, { useState } from 'react';
import type { AppProps } from '../../types';

// --- Helper Functions ---
const factorial = (n: number): number => {
    if (n < 0 || Math.floor(n) !== n) return NaN; // Factorial is only for non-negative integers
    if (n === 0 || n === 1) return 1;
    let result = 1;
    for (let i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
};

const evaluateExpression = (expr: string): string => {
    try {
        if (!expr) return '0';
        // Sanitize and prepare expression for evaluation
        let computableExpr = expr
            .replace(/×/g, '*')
            .replace(/÷/g, '/')
            .replace(/π/g, 'Math.PI')
            .replace(/√\(([^)]+)\)/g, 'Math.sqrt($1)')
            .replace(/log\(([^)]+)\)/g, 'Math.log10($1)')
            .replace(/ln\(([^)]+)\)/g, 'Math.log($1)')
            .replace(/sin\(([^)]+)\)/g, `Math.sin(Math.PI/180 * $1)`)
            .replace(/cos\(([^)]+)\)/g, `Math.cos(Math.PI/180 * $1)`)
            .replace(/tan\(([^)]+)\)/g, `Math.tan(Math.PI/180 * $1)`)
            .replace(/(\d+)!/g, 'factorial($1)')
            .replace(/\^/g, '**');

        // Basic validation to prevent arbitrary code execution
        const safeCharsRegex = /^[0-9+\-*/().\sMathPIsqrtlog10tancosinEfactorial**]+$/;
        if (!safeCharsRegex.test(computableExpr)) {
            return 'Invalid Input';
        }
        
        // Use the Function constructor for safer evaluation than direct eval()
        const result = new Function('factorial', `return ${computableExpr}`)(factorial);
        
        if (typeof result !== 'number' || !isFinite(result)) {
            return 'Error';
        }

        // Format to a reasonable precision to avoid floating point issues
        return String(parseFloat(result.toPrecision(14)));

    } catch (error) {
        return 'Error';
    }
};


// --- Button Configuration ---
const buttonConfig = [
    { label: 'C', action: 'clear', type: 'special' }, { label: 'DEL', action: 'delete', type: 'special' }, { label: '(', action: 'input', value: '(', type: 'special' }, { label: ')', action: 'input', value: ')', type: 'special' },
    { label: 'sin', action: 'function', value: 'sin', type: 'scientific' }, { label: 'cos', action: 'function', value: 'cos', type: 'scientific' }, { label: 'tan', action: 'function', value: 'tan', type: 'scientific' }, { label: '÷', action: 'input', value: '÷', type: 'operator' },
    { label: 'log', action: 'function', value: 'log', type: 'scientific' }, { label: 'ln', action: 'function', value: 'ln', type: 'scientific' }, { label: 'xʸ', action: 'input', value: '^', type: 'scientific' }, { label: '×', action: 'input', value: '×', type: 'operator' },
    { label: '7', action: 'input', value: '7', type: 'number' }, { label: '8', action: 'input', value: '8', type: 'number' }, { label: '9', action: 'input', value: '9', type: 'number' }, { label: '-', action: 'input', value: '-', type: 'operator' },
    { label: '4', action: 'input', value: '4', type: 'number' }, { label: '5', action: 'input', value: '5', type: 'number' }, { label: '6', action: 'input', value: '6', type: 'number' }, { label: '+', action: 'input', value: '+', type: 'operator' },
    { label: '1', action: 'input', value: '1', type: 'number' }, { label: '2', action: 'input', value: '2', type: 'number' }, { label: '3', action: 'input', value: '3', type: 'number' }, { label: '√', action: 'function', value: '√', type: 'scientific' },
    { label: '0', action: 'input', value: '0', type: 'number', span: 2 }, { label: '.', action: 'input', value: '.', type: 'number' }, { label: '=', action: 'equals', type: 'operator' },
];

const getButtonClass = (type: string): string => {
    switch (type) {
        case 'operator': return 'bg-orange-500 hover:bg-orange-600 text-white';
        case 'special': return 'bg-gray-400 hover:bg-gray-500 text-black';
        case 'number': return 'bg-gray-700 hover:bg-gray-600 text-white';
        case 'scientific': return 'bg-gray-600 hover:bg-gray-500 text-white';
        default: return 'bg-gray-700 hover:bg-gray-600 text-white';
    }
};

export const CalculatorApp: React.FC<AppProps> = () => {
    const [expression, setExpression] = useState('');
    const [history, setHistory] = useState('');

    const handleAction = (btn: typeof buttonConfig[0]) => {
        switch (btn.action) {
            case 'input':
                setExpression(prev => prev + btn.value);
                break;
            case 'function':
                setExpression(prev => prev + `${btn.value}(`);
                break;
            case 'clear':
                setExpression('');
                setHistory('');
                break;
            case 'delete':
                setExpression(prev => prev.slice(0, -1));
                break;
            case 'equals':
                if (!expression) return;
                const result = evaluateExpression(expression);
                setHistory(expression + ' =');
                setExpression(result);
                break;
        }
    };
    
    return (
        <div className="w-full h-full flex flex-col bg-[#1c1c1c] text-white p-2 font-sans select-none">
            <div className="flex-grow flex flex-col items-end justify-end p-4 text-right break-words">
                <div className="text-gray-400 text-xl h-8 min-h-[2rem] truncate w-full">{history}</div>
                <div className="text-6xl font-light tracking-tight truncate w-full">{expression || '0'}</div>
            </div>
            <div className="grid grid-cols-4 gap-2">
                {buttonConfig.map((btn) => (
                    <button
                        key={btn.label}
                        onClick={() => handleAction(btn)}
                        className={`
                            rounded-full h-16 text-2xl focus:outline-none transition-colors duration-150 flex items-center justify-center
                            ${getButtonClass(btn.type)}
                            ${btn.span === 2 ? 'col-span-2' : ''}
                        `}
                    >
                        {btn.label}
                    </button>
                ))}
            </div>
        </div>
    );
};
