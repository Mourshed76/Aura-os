import React from 'react';
import type { AppProps } from '../../types';

export const CalendarApp: React.FC<AppProps> = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-center text-center p-8 bg-white">
            <div className="text-6xl mb-4">📅</div>
            <h1 className="text-2xl font-semibold text-mac-text">Calendar</h1>
            <p className="text-mac-text-secondary mt-2">Coming Soon</p>
        </div>
    );
};