import React, { useState, useReducer, useMemo } from 'react';
import type { AppProps, Email } from '../../types';

type Mailbox = 'inbox' | 'sent' | 'trash';

// Mock Data
const initialEmails: Email[] = [
    { id: '1', sender: 'Aura Digest', subject: 'Your weekly summary', body: 'Here are your top updates for the week...', timestamp: Date.now() - 86400000, isRead: false, mailbox: 'inbox' },
    { id: '2', sender: 'Nexus Team', subject: 'Welcome to the new Nexus Browser!', body: 'Experience the web like never before with built-in AI features.', timestamp: Date.now() - 172800000, isRead: true, mailbox: 'inbox' },
    { id: '3', sender: 'App Store', subject: 'New apps you might like', body: 'Discover amazing new apps curated just for you in the App Store.', timestamp: Date.now() - 259200000, isRead: true, mailbox: 'inbox' },
];

// Reducer for state management
type Action = 
    | { type: 'MARK_READ'; payload: string }
    | { type: 'DELETE'; payload: string }
    | { type: 'SEND'; payload: Omit<Email, 'id' | 'timestamp' | 'isRead' | 'mailbox'> };

const emailsReducer = (state: Email[], action: Action): Email[] => {
    switch (action.type) {
        case 'MARK_READ':
            return state.map(email => email.id === action.payload ? { ...email, isRead: true } : email);
        case 'DELETE':
            return state.map(email => email.id === action.payload ? { ...email, mailbox: 'trash' } : email);
        case 'SEND':
            const newEmail: Email = {
                id: `email-${Date.now()}`,
                ...action.payload,
                timestamp: Date.now(),
                isRead: true,
                mailbox: 'sent',
            };
            return [newEmail, ...state];
        default:
            return state;
    }
};

const ComposeModal: React.FC<{ onClose: () => void; onSend: (email: Omit<Email, 'id' | 'timestamp' | 'isRead' | 'mailbox'>) => void }> = ({ onClose, onSend }) => {
    const [to, setTo] = useState('');
    const [subject, setSubject] = useState('');
    const [body, setBody] = useState('');

    const handleSend = () => {
        if (!to || !subject) return;
        onSend({ sender: 'you@aura.os', subject, body });
        onClose();
    };

    return (
        <div className="absolute inset-0 bg-black/30 backdrop-blur-sm z-10 flex items-center justify-center">
            <div className="w-[600px] bg-mac-gray rounded-lg shadow-2xl flex flex-col border border-black/20">
                <header className="h-9 bg-mac-gray-header/80 flex items-center justify-between px-4 text-mac-text shrink-0 border-b border-black/10">
                    <span className="font-semibold text-sm">New Message</span>
                    <button onClick={onClose} className="w-3.5 h-3.5 rounded-full bg-red-500 hover:bg-red-600 focus:outline-none border border-red-700/50"></button>
                </header>
                <div className="p-4 space-y-2">
                    <input type="text" value={to} onChange={e => setTo(e.target.value)} placeholder="To:" className="w-full bg-white p-2 rounded-md border border-gray-300 text-sm" />
                    <input type="text" value={subject} onChange={e => setSubject(e.target.value)} placeholder="Subject:" className="w-full bg-white p-2 rounded-md border border-gray-300 text-sm" />
                    <textarea value={body} onChange={e => setBody(e.target.value)} placeholder="Your message..." className="w-full h-48 bg-white p-2 rounded-md border border-gray-300 resize-none text-sm"></textarea>
                </div>
                <footer className="p-3 border-t border-black/10 flex justify-end">
                    <button onClick={handleSend} className="px-4 py-1.5 bg-mac-blue hover:bg-mac-blue/90 text-white font-medium rounded-md transition-colors text-sm">Send</button>
                </footer>
            </div>
        </div>
    );
};

export const MailApp: React.FC<AppProps> = () => {
    const [emails, dispatch] = useReducer(emailsReducer, initialEmails);
    const [activeMailbox, setActiveMailbox] = useState<Mailbox>('inbox');
    const [selectedEmailId, setSelectedEmailId] = useState<string | null>(null);
    const [isComposing, setIsComposing] = useState(false);

    const filteredEmails = useMemo(() => {
        return emails.filter(e => e.mailbox === activeMailbox).sort((a, b) => b.timestamp - a.timestamp);
    }, [emails, activeMailbox]);

    const selectedEmail = useMemo(() => {
        return emails.find(e => e.id === selectedEmailId);
    }, [emails, selectedEmailId]);

    const handleSelectEmail = (id: string) => {
        setSelectedEmailId(id);
        dispatch({ type: 'MARK_READ', payload: id });
    };

    const handleDelete = () => {
        if(selectedEmailId) {
            dispatch({ type: 'DELETE', payload: selectedEmailId });
            setSelectedEmailId(null);
        }
    }

    const handleSend = (email: Omit<Email, 'id' | 'timestamp' | 'isRead' | 'mailbox'>) => {
        dispatch({ type: 'SEND', payload: email });
    };

    return (
        <div className="w-full h-full flex bg-mac-gray text-mac-text">
            {isComposing && <ComposeModal onClose={() => setIsComposing(false)} onSend={handleSend} />}
            {/* Sidebar */}
            <aside className="w-48 h-full bg-mac-gray-header/60 p-3 shrink-0 border-r border-black/10">
                <button onClick={() => setIsComposing(true)} className="w-full mb-4 px-4 py-1.5 bg-mac-blue hover:bg-mac-blue/90 text-white font-medium rounded-md transition-colors text-sm">Compose</button>
                <div className="space-y-1">
                    <SidebarItem icon="📥" label="Inbox" isActive={activeMailbox === 'inbox'} onClick={() => setActiveMailbox('inbox')} count={emails.filter(e => e.mailbox === 'inbox' && !e.isRead).length} />
                    <SidebarItem icon="📤" label="Sent" isActive={activeMailbox === 'sent'} onClick={() => setActiveMailbox('sent')} />
                    <SidebarItem icon="🗑️" label="Trash" isActive={activeMailbox === 'trash'} onClick={() => setActiveMailbox('trash')} />
                </div>
            </aside>

            {/* Email List */}
            <section className="w-72 h-full border-r border-black/10 flex flex-col">
                <header className="p-3 border-b border-black/10 shrink-0">
                    <h2 className="font-bold text-lg capitalize">{activeMailbox}</h2>
                </header>
                <div className="flex-grow overflow-y-auto">
                    {filteredEmails.map(email => (
                        <EmailListItem key={email.id} email={email} isActive={email.id === selectedEmailId} onClick={() => handleSelectEmail(email.id)} />
                    ))}
                </div>
            </section>

            {/* Reading Pane */}
            <main className="flex-grow flex flex-col">
                {selectedEmail ? (
                    <>
                        <header className="p-4 border-b border-black/10 shrink-0">
                            <h2 className="text-xl font-bold mb-1">{selectedEmail.subject}</h2>
                            <div className="flex justify-between items-center">
                                <p className="text-sm text-mac-text-secondary">From: <span className="font-medium text-mac-text">{selectedEmail.sender}</span></p>
                                <button onClick={handleDelete} className="text-xl text-gray-500 hover:text-red-500">🗑️</button>
                            </div>
                        </header>
                        <div className="flex-grow p-6 overflow-y-auto whitespace-pre-wrap">
                            {selectedEmail.body}
                        </div>
                    </>
                ) : (
                    <div className="w-full h-full flex items-center justify-center text-mac-text-secondary">
                        <p>Select an email to read</p>
                    </div>
                )}
            </main>
        </div>
    );
};

// Sub-components
const SidebarItem: React.FC<{ icon: string; label: string; isActive: boolean; onClick: () => void; count?: number }> = ({ icon, label, isActive, onClick, count = 0 }) => (
    <button
        onClick={onClick}
        className={`flex items-center justify-between w-full text-left px-3 py-2 rounded-lg transition-colors duration-150 ${
            isActive ? 'bg-mac-blue/20 text-mac-blue' : 'hover:bg-gray-200/50'
        }`}
    >
        <div className="flex items-center">
            <span className="text-md mr-3">{icon}</span>
            <span className="font-medium text-sm">{label}</span>
        </div>
        {count > 0 && <span className="text-xs font-bold bg-mac-blue text-white rounded-full px-2 py-0.5">{count}</span>}
    </button>
);

const EmailListItem: React.FC<{ email: Email; isActive: boolean; onClick: () => void }> = ({ email, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`w-full text-left p-3 border-b border-gray-200/80 flex items-start gap-3 ${isActive ? 'bg-blue-100/50' : 'hover:bg-gray-100/50'}`}
    >
        {!email.isRead && <div className="w-2.5 h-2.5 bg-mac-blue rounded-full mt-1.5 shrink-0"></div>}
        <div className={`flex-grow ${email.isRead ? 'ml-[18px]' : ''}`}>
            <h3 className="font-bold text-sm truncate">{email.sender}</h3>
            <p className="text-xs font-medium text-gray-700 truncate">{email.subject}</p>
            <p className="text-xs text-gray-500 truncate">{new Date(email.timestamp).toLocaleDateString()}</p>
        </div>
    </button>
);
