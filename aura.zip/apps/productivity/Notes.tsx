import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import type { Note, AppProps, ChecklistItem } from '../../types';

const useNotes = () => {
    const [notes, setNotes] = useState<Note[]>(() => {
        try {
            const savedNotes = localStorage.getItem('aura-notes');
            const parsedNotes = savedNotes ? JSON.parse(savedNotes) : [];
            // Migration for old notes to add `type`
            return parsedNotes.map((note: any) => ({
                id: note.id,
                title: note.title || 'New Note',
                content: note.content,
                updatedAt: note.updatedAt,
                type: note.type || 'text', // Default to 'text' if type is missing
            }));
        } catch (error) {
            console.error('Failed to parse notes from localStorage', error);
            return [];
        }
    });

    useEffect(() => {
        localStorage.setItem('aura-notes', JSON.stringify(notes));
    }, [notes]);

    const createNote = () => {
        const newNote: Note = {
            id: `note-${Date.now()}`,
            title: 'New Note',
            content: '',
            updatedAt: Date.now(),
            type: 'text',
        };
        setNotes(prev => [newNote, ...prev]);
        return newNote.id;
    };

    const updateNote = (id: string, newTitle: string, newContent: string) => {
        setNotes(prev =>
            prev.map(note =>
                note.id === id ? { ...note, title: newTitle, content: newContent, updatedAt: Date.now() } : note
            ).sort((a, b) => b.updatedAt - a.updatedAt)
        );
    };

    const deleteNote = (id: string) => {
        setNotes(prev => prev.filter(note => note.id !== id));
    };

    const toggleNoteType = (id: string) => {
        setNotes(prev => {
            return prev.map(note => {
                if (note.id !== id) return note;

                if (note.type === 'text') {
                    // Convert text to checklist
                    const items: ChecklistItem[] = note.content
                        .split('\n')
                        .filter(line => line.trim() !== '')
                        .map((line, index) => ({
                            id: `item-${Date.now()}-${index}`,
                            text: line,
                            completed: false
                        }));
                    return { ...note, type: 'checklist', content: JSON.stringify(items) };
                } else {
                    // Convert checklist to text
                    try {
                        const items: ChecklistItem[] = JSON.parse(note.content);
                        const textContent = items.map(item => item.text).join('\n');
                        return { ...note, type: 'text', content: textContent };
                    } catch {
                        // If parsing fails, just clear it
                        return { ...note, type: 'text', content: '' };
                    }
                }
            });
        });
    };

    return { notes, createNote, updateNote, deleteNote, toggleNoteType };
};

const NoteListItem: React.FC<{ note: Note; isActive: boolean; onClick: () => void }> = ({ note, isActive, onClick }) => {
    const subtitle = new Date(note.updatedAt).toLocaleDateString();

    return (
        <button
            onClick={onClick}
            className={`w-full text-left p-3 rounded-lg border-b border-gray-200/50 ${
                isActive ? 'bg-yellow-200/60' : 'hover:bg-gray-200/40'
            }`}
        >
            <h3 className="font-bold text-sm truncate text-gray-800">{note.title}</h3>
            <p className="text-xs text-gray-500">{subtitle}</p>
        </button>
    );
};

const ChecklistEditor: React.FC<{ noteContent: string; onContentChange: (newContent: string) => void; }> = ({ noteContent, onContentChange }) => {
    const [items, setItems] = useState<ChecklistItem[]>(() => {
        try {
            return JSON.parse(noteContent);
        } catch {
            return [];
        }
    });
    const lastFocusedInput = useRef<HTMLInputElement | null>(null);


    useEffect(() => {
        // This effect ensures that if the underlying note content changes from outside, the editor updates.
        try {
            setItems(JSON.parse(noteContent));
        } catch {
            setItems([]);
        }
    }, [noteContent]);

    const updateItems = (newItems: ChecklistItem[]) => {
        setItems(newItems);
        onContentChange(JSON.stringify(newItems));
    };

    const handleItemChange = (itemId: string, newText: string) => {
        const newItems = items.map(item => item.id === itemId ? { ...item, text: newText } : item);
        updateItems(newItems);
    };

    const handleToggleComplete = (itemId: string) => {
        const newItems = items.map(item => item.id === itemId ? { ...item, completed: !item.completed } : item);
        updateItems(newItems);
    };

    const handleAddNewItem = (afterItemId?: string) => {
        const newItem: ChecklistItem = { id: `item-${Date.now()}`, text: '', completed: false };
        let newItems;
        if (afterItemId) {
            const index = items.findIndex(item => item.id === afterItemId);
            newItems = [...items.slice(0, index + 1), newItem, ...items.slice(index + 1)];
        } else {
            newItems = [...items, newItem];
        }
        updateItems(newItems);
        // Focus the new input after a short delay
        setTimeout(() => document.getElementById(newItem.id)?.focus(), 50);
    };

    const handleDeleteItem = (itemId: string) => {
        const index = items.findIndex(item => item.id === itemId);
        lastFocusedInput.current = document.querySelector(`[data-prev-id="${itemId}"]`);
        
        updateItems(items.filter(item => item.id !== itemId));

        setTimeout(() => {
            lastFocusedInput.current?.focus()
        }, 50);
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, itemId: string) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            handleAddNewItem(itemId);
        }
        if (e.key === 'Backspace' && (e.target as HTMLInputElement).value === '') {
            e.preventDefault();
            handleDeleteItem(itemId);
        }
    };
    
    return (
        <div className="w-full flex-grow p-6 overflow-y-auto">
            <div className="space-y-2">
                 {items.map((item, index) => (
                    <div key={item.id} className="flex items-center gap-3 group">
                        <input
                            type="checkbox"
                            checked={item.completed}
                            onChange={() => handleToggleComplete(item.id)}
                            className="w-5 h-5 rounded-full text-yellow-500 bg-transparent border-gray-400 focus:ring-yellow-500 shrink-0"
                        />
                        <input
                            id={item.id}
                            data-prev-id={items[index - 1]?.id}
                            type="text"
                            value={item.text}
                            onChange={(e) => handleItemChange(item.id, e.target.value)}
                            onKeyDown={(e) => handleKeyDown(e, item.id)}
                            className={`flex-grow bg-transparent border-none focus:ring-0 p-1 ${item.completed ? 'line-through text-gray-400' : 'text-[#3e2723]'}`}
                            placeholder="New item..."
                        />
                        <button onClick={() => handleDeleteItem(item.id)} className="text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">×</button>
                    </div>
                ))}
            </div>
            <button onClick={() => handleAddNewItem(items[items.length - 1]?.id)} className="mt-4 text-yellow-600 hover:text-yellow-800 font-semibold">+ Add Item</button>
        </div>
    )
};

export const NotesApp: React.FC<AppProps> = () => {
    const { notes, createNote, updateNote, deleteNote, toggleNoteType } = useNotes();
    const [activeNoteId, setActiveNoteId] = useState<string | null>(notes.find(n => n.type === 'text')?.[0]?.id || notes[0]?.id || null);

    useEffect(() => {
        if (!activeNoteId && notes.length > 0) {
            setActiveNoteId(notes[0].id);
        }
        if (activeNoteId && !notes.find(n => n.id === activeNoteId)) {
            setActiveNoteId(notes[0]?.id || null);
        }
    }, [notes, activeNoteId]);

    const handleCreateNote = () => {
        const newNoteId = createNote();
        setActiveNoteId(newNoteId);
    };

    const handleDeleteNote = () => {
        if (activeNoteId) {
            deleteNote(activeNoteId);
        }
    }

    const activeNote = useMemo(() => notes.find(n => n.id === activeNoteId), [notes, activeNoteId]);

    const handleContentChange = useCallback((newContent: string) => {
        if (activeNote) {
            updateNote(activeNote.id, activeNote.title, newContent);
        }
    }, [activeNote, updateNote]);

    return (
        <div className="w-full h-full flex bg-[#fffbeb]">
            <aside className="w-56 h-full bg-yellow-100/50 p-2 shrink-0 border-r border-yellow-200/50 flex flex-col">
                <div className="flex-grow overflow-y-auto space-y-1">
                    {notes.map(note => (
                        <NoteListItem
                            key={note.id}
                            note={note}
                            isActive={note.id === activeNoteId}
                            onClick={() => setActiveNoteId(note.id)}
                        />
                    ))}
                </div>
                <div className="flex-shrink-0 p-1 flex items-center justify-between border-t border-yellow-200/50">
                    <button onClick={handleCreateNote} className="text-gray-500 hover:text-black text-xl p-1 font-mono">+</button>
                    <button onClick={handleDeleteNote} disabled={!activeNoteId} className="text-gray-500 hover:text-red-500 disabled:opacity-50 text-xl p-1">🗑️</button>
                </div>
            </aside>
            <main className="flex-grow flex flex-col">
                {activeNote ? (
                    <>
                        <div className="flex items-center border-b border-yellow-200/50">
                            <input
                                type="text"
                                value={activeNote.title}
                                onChange={(e) => updateNote(activeNote.id, e.target.value, activeNote.content)}
                                className="w-full p-2 text-center text-lg font-semibold bg-transparent focus:outline-none focus:ring-0"
                                placeholder="Note Title"
                            />
                            <button
                                onClick={() => toggleNoteType(activeNote.id)}
                                title={activeNote.type === 'text' ? 'Convert to Checklist' : 'Convert to Text'}
                                className="p-2 text-xl text-gray-500 hover:text-black mr-2"
                            >
                                {activeNote.type === 'text' ? '☑' : '✍'}
                            </button>
                        </div>
                        
                        {activeNote.type === 'text' ? (
                            <textarea
                                key={activeNote.id}
                                className="w-full flex-grow p-6 resize-none border-none focus:ring-0 bg-transparent text-[#3e2723] font-serif text-lg leading-relaxed"
                                value={activeNote.content}
                                onChange={(e) => handleContentChange(e.target.value)}
                                spellCheck="false"
                                placeholder="Start writing..."
                            />
                        ) : (
                            <ChecklistEditor
                                key={activeNote.id}
                                noteContent={activeNote.content}
                                onContentChange={handleContentChange}
                            />
                        )}
                    </>
                ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-gray-500">
                        <div className="text-3xl mb-2">📝</div>
                        <h2 className="text-xl font-semibold">No Note Selected</h2>
                        <p>Create a new note to get started.</p>
                    </div>
                )}
            </main>
        </div>
    );
};