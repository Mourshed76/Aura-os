
import React, { useState, useMemo } from 'react';
import { OS_NAME, APPS } from '../../constants';
import type { AppDefinition, AppCategory, AppProps } from '../../types';
import { useSettings } from '../../context/SettingsContext';

const CircularProgress: React.FC<{ progress: number }> = ({ progress }) => {
    const radius = 12;
    const stroke = 2.5;
    const normalizedRadius = radius - stroke * 2;
    const circumference = normalizedRadius * 2 * Math.PI;
    const strokeDashoffset = circumference - (progress / 100) * circumference;

    return (
        <div className="relative w-7 h-7">
            <svg
                height="100%"
                width="100%"
                viewBox="0 0 28 28"
                className="transform -rotate-90"
            >
                <circle
                    stroke="#e6e6e6"
                    fill="transparent"
                    strokeWidth={stroke}
                    r={normalizedRadius}
                    cx={radius}
                    cy={radius}
                />
                <circle
                    stroke="url(#gradient)"
                    fill="transparent"
                    strokeWidth={stroke}
                    strokeDasharray={`${circumference} ${circumference}`}
                    style={{ strokeDashoffset, strokeLinecap: 'round' }}
                    r={normalizedRadius}
                    cx={radius}
                    cy={radius}
                />
                 <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#3b82f6" />
                        <stop offset="100%" stopColor="#8b5cf6" />
                    </linearGradient>
                </defs>
            </svg>
            <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-mac-blue">
                {progress}
            </span>
        </div>
    );
};


const AppActionButton: React.FC<{ app: AppDefinition }> = ({ app }) => {
    const { installedApps, installingProgress, installApp } = useSettings();
    const isInstalled = installedApps.includes(app.id);
    const progress = installingProgress[app.id];
    const isCurrentlyInstalling = progress !== undefined;

    if (isCurrentlyInstalling) {
        return (
            <div className="w-20 h-7 flex items-center justify-center">
                 <CircularProgress progress={progress} />
            </div>
        );
    }

    if (isInstalled) {
        return (
            <button
                className="bg-gray-200 text-mac-blue font-bold py-1 px-4 rounded-full text-sm w-20"
                aria-label={`Open ${app.name}`}
            >
                OPEN
            </button>
        );
    }

    return (
        <button
            onClick={() => installApp(app.id)}
            className="bg-blue-100 hover:bg-blue-200 text-mac-blue font-bold py-1 px-4 rounded-full text-sm w-20"
            aria-label={`Get ${app.name}`}
        >
            GET
        </button>
    );
};

const AppCard: React.FC<{ app: AppDefinition }> = ({ app }) => (
    <div className="bg-mac-gray-light p-4 rounded-xl flex items-center space-x-4 border border-gray-200/80">
        <div className="w-16 h-16 flex-shrink-0">{app.icon}</div>
        <div className="flex-grow">
            <h3 className="text-md font-bold text-mac-text">{app.name}</h3>
            <p className="text-xs text-mac-text-secondary mt-0.5">{app.description}</p>
            <p className="text-xs text-mac-text-secondary mt-1 font-mono">{app.sizeMB.toFixed(1)} MB</p>
        </div>
        <AppActionButton app={app} />
    </div>
);


const SidebarItem: React.FC<{ icon: string; label: string; isActive: boolean; onClick: () => void; }> = ({ icon, label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`flex items-center w-full text-left px-3 py-2 rounded-lg transition-colors duration-150 ${
            isActive ? 'bg-mac-blue/20 text-mac-blue' : 'hover:bg-gray-200/50'
        }`}
    >
        <span className="text-xl mr-3">{icon}</span>
        <span className="font-medium">{label}</span>
    </button>
);


type StoreCategory = 'Discover' | 'Apps' | 'Games' | 'Entertainment';

export const AppStoreApp: React.FC<AppProps> = () => {
    const [activeCategory, setActiveCategory] = useState<StoreCategory>('Discover');

    const filteredApps = useMemo(() => {
        const allApps = APPS.filter(app => app.id !== 'finder');
        if (activeCategory === 'Discover') {
            return allApps;
        }
        if (activeCategory === 'Apps') {
            return allApps.filter(app => app.category === 'Productivity' || app.category === 'System');
        }
        return allApps.filter(app => app.category === activeCategory);
    }, [activeCategory]);

    return (
        <div className="w-full h-full bg-mac-gray-light text-mac-text flex">
            <aside className="w-56 h-full bg-mac-gray-header/60 p-4 shrink-0 border-r border-black/10">
                 <h1 className="text-xl font-bold px-3 mb-4">App Store</h1>
                <div className="space-y-1">
                    <SidebarItem icon="⭐" label="Discover" isActive={activeCategory === 'Discover'} onClick={() => setActiveCategory('Discover')} />
                    <SidebarItem icon="💻" label="Apps" isActive={activeCategory === 'Apps'} onClick={() => setActiveCategory('Apps')} />
                    <SidebarItem icon="🎮" label="Games" isActive={activeCategory === 'Games'} onClick={() => setActiveCategory('Games')} />
                    <SidebarItem icon="🎬" label="Entertainment" isActive={activeCategory === 'Entertainment'} onClick={() => setActiveCategory('Entertainment')} />
                </div>
            </aside>
            <main className="flex-grow p-6 overflow-y-auto">
                 <header className="mb-8">
                    <h1 className="text-4xl font-extrabold text-mac-text">
                        {activeCategory === 'Discover' ? `Welcome to the App Store` : activeCategory}
                    </h1>
                    <p className="text-mac-text-secondary mt-1">
                         Curated for {OS_NAME}
                    </p>
                </header>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {filteredApps.map(app => (
                        <AppCard key={app.id} app={app} />
                    ))}
                </div>
            </main>
        </div>
    );
};
