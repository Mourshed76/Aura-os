import React, { useState, useCallback, useEffect, useRef } from 'react';
import type { Tab, AppProps } from '../../types';

const isURL = (str: string): boolean => {
    try {
        // A simple check: must contain a dot and no spaces.
        // A more robust regex could be used, but this is fine for a simulation.
        if (str.includes('.') && !str.includes(' ')) {
            new URL(str.startsWith('http') ? str : `https://${str}`);
            return true;
        }
    } catch (_) {
        return false;
    }
    return false;
};

const getFaviconUrl = (url: string) => {
    try {
        const hostname = new URL(url).hostname;
        return `https://www.google.com/s2/favicons?domain=${hostname}&sz=32`;
    } catch {
        return 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs='; // Transparent pixel
    }
};

const FAVORITES = [
    { name: 'Google', url: 'https://www.google.com', color: '#4285F4' },
    { name: 'GitHub', url: 'https://github.com', color: '#333333' },
    { name: 'YouTube', url: 'https://www.youtube.com', color: '#FF0000' },
    { name: 'Wikipedia', url: 'https://www.wikipedia.org', color: '#000000' },
    { name: 'React', url: 'https://react.dev', color: '#61DAFB' },
    { name: 'Vercel', url: 'https://vercel.com', color: '#000000' },
];

const HomePage: React.FC<{ onNavigate: (url: string) => void }> = ({ onNavigate }) => (
    <div className="w-full h-full flex flex-col items-center justify-center bg-gray-100 p-8">
        <h1 className="text-5xl font-bold text-gray-700 mb-2">Nexus</h1>
        <p className="text-gray-500 mb-12">Your intelligent portal to the web.</p>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-6">
            {FAVORITES.map(fav => (
                <div key={fav.name} onClick={() => onNavigate(fav.url)} className="flex flex-col items-center cursor-pointer group">
                    <div className="w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold transition-transform group-hover:scale-110" style={{ backgroundColor: fav.color }}>
                        {fav.name.charAt(0)}
                    </div>
                    <span className="mt-2 text-sm text-gray-600 font-medium">{fav.name}</span>
                </div>
            ))}
        </div>
    </div>
);

export const BrowserApp: React.FC<AppProps> = () => {
    const createNewTab = (url?: string): Tab => {
        const id = `tab-${Date.now()}`;
        const isUrl = url && isURL(url);
        const history = isUrl ? [url] : [];
        return {
            id,
            title: isUrl ? new URL(url).hostname : 'New Tab',
            type: isUrl ? 'webpage' : 'home',
            history,
            historyIndex: history.length - 1,
            isLoading: isUrl,
            favicon: isUrl ? getFaviconUrl(url) : undefined,
        };
    };

    const [tabs, setTabs] = useState<Tab[]>([createNewTab()]);
    const [activeTabId, setActiveTabId] = useState<string>(tabs[0].id);
    const inputRef = useRef<HTMLInputElement>(null);
    const iframeRef = useRef<HTMLIFrameElement>(null);

    const activeTab = tabs.find(t => t.id === activeTabId);

    const updateTab = useCallback((tabId: string, updates: Partial<Tab>) => {
        setTabs(prevTabs =>
            prevTabs.map(tab => (tab.id === tabId ? { ...tab, ...updates } : tab))
        );
    }, []);

    const handleNavigate = useCallback((tabId: string, input: string) => {
        const isInputUrl = isURL(input);
        const url = isInputUrl && !input.startsWith('http') ? `https://${input}` : input;

        if (isInputUrl) {
            const currentTab = tabs.find(t => t.id === tabId);
            if (!currentTab) return;

            const newHistory = currentTab.history.slice(0, currentTab.historyIndex + 1);
            newHistory.push(url);

            updateTab(tabId, {
                type: 'webpage',
                history: newHistory,
                historyIndex: newHistory.length - 1,
                isLoading: true,
                favicon: getFaviconUrl(url),
                title: 'Loading...'
            });
        } else {
            // Placeholder for search functionality
            updateTab(tabId, { type: 'search', title: `Search: ${input}`, history: [], historyIndex: -1, isLoading: false });
        }
    }, [tabs, updateTab]);

    const handleGo = () => {
        if (inputRef.current?.value && activeTabId) {
            handleNavigate(activeTabId, inputRef.current.value);
        }
    };
    
    const handleBack = () => {
        if (activeTab && activeTab.historyIndex > 0) {
            updateTab(activeTabId, { historyIndex: activeTab.historyIndex - 1, isLoading: true });
        }
    };

    const handleForward = () => {
        if (activeTab && activeTab.historyIndex < activeTab.history.length - 1) {
            updateTab(activeTabId, { historyIndex: activeTab.historyIndex + 1, isLoading: true });
        }
    };

    const handleRefresh = () => {
        if (iframeRef.current) {
            updateTab(activeTabId, { isLoading: true });
            iframeRef.current.src = iframeRef.current.src;
        }
    };
    
    const addTab = () => {
        const newTab = createNewTab();
        setTabs([...tabs, newTab]);
        setActiveTabId(newTab.id);
    };

    const closeTab = (tabId: string) => {
        const tabIndex = tabs.findIndex(t => t.id === tabId);
        let newTabs = tabs.filter(t => t.id !== tabId);
        if (newTabs.length === 0) {
            newTabs = [createNewTab()];
        }
        if (tabId === activeTabId) {
            setActiveTabId(newTabs[Math.max(0, tabIndex - 1)].id);
        }
        setTabs(newTabs);
    };

    const handleIframeLoad = () => {
        if (activeTab) {
            try {
                const title = iframeRef.current?.contentWindow?.document.title || new URL(activeTab.history[activeTab.historyIndex]).hostname;
                 updateTab(activeTabId, { isLoading: false, title });
            } catch (e) {
                 updateTab(activeTabId, { isLoading: false, title: activeTab.history[activeTab.historyIndex] });
            }
        }
    };
    
    useEffect(() => {
        if (inputRef.current && activeTab) {
            if (activeTab.type === 'webpage') {
                inputRef.current.value = activeTab.history[activeTab.historyIndex];
            } else if (activeTab.type === 'search') {
                inputRef.current.value = activeTab.title.replace('Search: ', '');
            }
            else {
                inputRef.current.value = '';
            }
        }
    }, [activeTab]);

    return (
        <div className="w-full h-full flex flex-col bg-gray-200">
            <header className="flex-shrink-0 bg-mac-gray-header/80 backdrop-blur-xl border-b border-gray-300">
                <div className="flex items-center h-10">
                    <div className="flex-grow flex items-end h-full overflow-x-auto">
                        {tabs.map(tab => (
                            <div
                                key={tab.id}
                                onClick={() => setActiveTabId(tab.id)}
                                className={`flex items-center justify-between px-3 h-full border-r border-gray-300 cursor-pointer max-w-48 ${tab.id === activeTabId ? 'bg-mac-gray' : 'bg-mac-gray/50 hover:bg-mac-gray/80'}`}
                                style={{borderTopLeftRadius: '6px', borderTopRightRadius: '6px'}}
                            >
                                {tab.isLoading ? (
                                    <div className="w-4 h-4 border-2 border-gray-400 border-t-mac-blue rounded-full animate-spin mr-2"></div>
                                ) : (
                                    <img src={tab.favicon} alt="" className="w-4 h-4 mr-2" />
                                )}
                                <span className="text-xs font-medium truncate">{tab.title}</span>
                                <button onClick={(e) => { e.stopPropagation(); closeTab(tab.id); }} className="ml-2 text-gray-500 hover:text-black rounded-full w-4 h-4 text-xs flex items-center justify-center shrink-0">×</button>
                            </div>
                        ))}
                    </div>
                    <button onClick={addTab} className="px-3 h-full text-lg font-light hover:bg-black/10">+</button>
                </div>
                <div className="p-2 flex items-center gap-2">
                     <button onClick={handleBack} disabled={!activeTab || activeTab.historyIndex < 1} className="text-xl disabled:opacity-30">‹</button>
                    <button onClick={handleForward} disabled={!activeTab || activeTab.historyIndex >= activeTab.history.length - 1} className="text-xl disabled:opacity-30">›</button>
                    <button onClick={handleRefresh} disabled={!activeTab || activeTab.isLoading} className="text-base disabled:opacity-30">⟳</button>
                    <input
                        ref={inputRef}
                        onKeyPress={(e) => e.key === 'Enter' && handleGo()}
                        placeholder="Search or type a URL"
                        className="flex-grow bg-white text-mac-text px-3 py-1 rounded-md focus:outline-none focus:ring-2 focus:ring-mac-blue/50 border border-gray-300 text-sm"
                    />
                </div>
            </header>
            <main className="flex-grow overflow-auto bg-gray-100">
                {tabs.map(tab => (
                    <div key={tab.id} style={{ display: tab.id === activeTabId ? 'block' : 'none', width: '100%', height: '100%' }}>
                        {tab.type === 'home' && <HomePage onNavigate={(url) => handleNavigate(tab.id, url)} />}
                        {tab.type === 'webpage' && tab.history.length > 0 && (
                             <iframe 
                                ref={tab.id === activeTabId ? iframeRef : null}
                                src={tab.history[tab.historyIndex]} 
                                className="w-full h-full border-0" 
                                title={tab.title} 
                                sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-modals"
                                onLoad={handleIframeLoad}
                                onError={() => updateTab(tab.id, { isLoading: false, title: 'Failed to load' })}
                            />
                        )}
                         {tab.type === 'search' && (
                            <div className="text-center text-gray-500 p-8">
                                <h2 className="text-2xl font-semibold mb-2">Search results for "{tab.title.replace('Search: ', '')}"</h2>
                                <p>(Search functionality is under construction)</p>
                            </div>
                         )}
                    </div>
                ))}
            </main>
        </div>
    );
};