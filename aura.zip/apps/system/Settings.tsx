
import React, { useState } from 'react';
import { useSettings } from '../../context/SettingsContext';
import { OS_NAME, WALLPAPERS } from '../../constants';
import type { AppProps } from '../../types';

type SettingsPanel = 'Appearance' | 'Dock & Menu Bar' | 'Privacy & Security' | 'Aura Assistant' | 'Users & Accounts' | 'About';

const SidebarItem: React.FC<{
    icon: string;
    label: SettingsPanel;
    isActive: boolean;
    onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`flex items-center w-full text-left px-3 py-2 rounded-lg transition-colors duration-150 ${
            isActive ? 'bg-mac-blue/20 text-mac-blue' : 'hover:bg-gray-200/50'
        }`}
    >
        <span className="text-xl mr-3">{icon}</span>
        <span className="font-medium text-sm">{label}</span>
    </button>
);

const AppearancePanel: React.FC = () => {
    const { wallpaper, setWallpaper } = useSettings();

    return (
        <div>
            <h2 className="text-xl font-bold mb-4">Appearance</h2>
            <p className="text-mac-text-secondary mb-6">Select a desktop wallpaper.</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {WALLPAPERS.map((wp) => (
                    <div
                        key={wp.name}
                        className={`relative rounded-lg overflow-hidden border-2 cursor-pointer transition-all ${
                            wallpaper === wp.url ? 'border-mac-blue' : 'border-transparent'
                        }`}
                        onClick={() => setWallpaper(wp.url)}
                        aria-label={`Select ${wp.name} wallpaper`}
                    >
                        <img src={wp.url} alt={wp.name} className="w-full h-24 object-cover" />
                        <div className="absolute inset-0 bg-black/20"></div>
                        <p className="absolute bottom-1 left-2 text-white text-xs font-semibold" style={{ textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}>{wp.name}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

const DockPanel: React.FC = () => {
    const { dockSize, setDockSize, dockMagnification, setDockMagnification } = useSettings();
    return (
        <div>
            <h2 className="text-xl font-bold mb-4">Dock & Menu Bar</h2>
            <div className="space-y-6">
                <div>
                    <label htmlFor="dock-size" className="block text-sm font-medium text-mac-text mb-2">
                        Size: <span className="text-mac-text-secondary font-normal">{dockSize}px</span>
                    </label>
                    <input
                        id="dock-size"
                        type="range"
                        min="40"
                        max="80"
                        step="4"
                        value={dockSize}
                        onChange={(e) => setDockSize(Number(e.target.value))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-mac-blue"
                    />
                </div>
                <div>
                    <label htmlFor="dock-mag" className="block text-sm font-medium text-mac-text mb-2">
                        Magnification: <span className="text-mac-text-secondary font-normal">{Math.round(dockMagnification * 100)}%</span>
                    </label>
                    <input
                        id="dock-mag"
                        type="range"
                        min="1"
                        max="2"
                        step="0.1"
                        value={dockMagnification}
                        onChange={(e) => setDockMagnification(Number(e.target.value))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-mac-blue"
                    />
                </div>
            </div>
        </div>
    );
};

const PrivacySecurityPanel: React.FC = () => {
    const { setPrivateAlbumPassword } = useSettings();
    const [newPassword, setNewPassword] = useState('');
    const [feedback, setFeedback] = useState('');

    const handleSave = () => {
        if (newPassword.length < 4) {
            setFeedback('Password must be at least 4 characters long.');
            setTimeout(() => setFeedback(''), 3000);
            return;
        }
        setPrivateAlbumPassword(newPassword);
        setFeedback('Password updated successfully!');
        setNewPassword('');
        setTimeout(() => setFeedback(''), 3000);
    };

    return (
        <div>
            <h2 className="text-xl font-bold mb-4">Privacy & Security</h2>
            <div className="space-y-6 max-w-sm">
                 <div>
                    <h3 className="font-semibold mb-2">Photos Private Album</h3>
                    <p className="text-mac-text-secondary text-sm mb-3">Set a password to protect your private album in the Photos app.</p>
                    <div className="flex items-center space-x-2">
                        <input
                            type="password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            placeholder="Enter new password"
                            className="flex-grow bg-white text-mac-text px-3 py-1.5 rounded-md focus:outline-none focus:ring-2 focus:ring-mac-blue/50 border border-gray-300 text-sm"
                        />
                         <button
                            onClick={handleSave}
                            className="px-4 py-1.5 bg-mac-blue hover:bg-mac-blue/90 text-white font-medium rounded-md transition-colors text-sm"
                        >
                            Save
                        </button>
                    </div>
                     {feedback && <p className="text-green-600 text-xs mt-2">{feedback}</p>}
                </div>
            </div>
        </div>
    );
};

const AuraAssistantPanel: React.FC = () => {
    const { clearAuraChat } = useSettings();
    const [cleared, setCleared] = useState(false);

    const handleClear = () => {
        clearAuraChat();
        setCleared(true);
        setTimeout(() => setCleared(false), 2000);
    }
    return (
        <div>
            <h2 className="text-xl font-bold mb-4">Aura Assistant</h2>
             <p className="text-mac-text-secondary mb-6">Manage settings for your AI assistant.</p>
            <div className="flex items-center space-x-4">
                <button
                    onClick={handleClear}
                    className="px-4 py-1.5 bg-gray-200 hover:bg-gray-300 text-mac-text font-medium rounded-md transition-colors border border-black/10 text-sm"
                >
                    Clear Chat History
                </button>
                {cleared && <span className="text-green-600 text-sm">History Cleared!</span>}
            </div>
        </div>
    );
};


const UsersAccountsPanel: React.FC = () => {
    const { username, logout } = useSettings();
    return (
        <div>
            <h2 className="text-xl font-bold mb-4">Users & Accounts</h2>
            <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-center justify-between">
                <div>
                    <p className="font-bold text-lg">{username}</p>
                    <p className="text-sm text-mac-text-secondary">Administrator</p>
                </div>
                <button
                    onClick={logout}
                    className="px-4 py-1.5 bg-red-500 hover:bg-red-600 text-white font-medium rounded-md transition-colors text-sm"
                >
                    Log Out
                </button>
            </div>
        </div>
    );
}

const AboutPanel: React.FC = () => (
     <div>
        <h2 className="text-xl font-bold mb-4">About {OS_NAME}</h2>
        <div className="flex flex-col items-center text-center">
            <div className="text-7xl mb-4">✨</div>
            <h3 className="text-2xl font-bold">{OS_NAME}</h3>
            <p className="text-mac-text-secondary mt-1">Version 1.0 (Web)</p>
            <p className="mt-4 max-w-sm">
                A modern, web-based operating system inspired by the elegance and simplicity of macOS. 
                Built with React, TypeScript, and Tailwind CSS.
            </p>
        </div>
    </div>
);


export const SettingsApp: React.FC<AppProps> = () => {
    const [activePanel, setActivePanel] = useState<SettingsPanel>('Appearance');

    const renderPanel = () => {
        switch (activePanel) {
            case 'Appearance': return <AppearancePanel />;
            case 'Dock & Menu Bar': return <DockPanel />;
            case 'Privacy & Security': return <PrivacySecurityPanel />;
            case 'Aura Assistant': return <AuraAssistantPanel />;
            case 'Users & Accounts': return <UsersAccountsPanel />;
            case 'About': return <AboutPanel />;
            default: return <AppearancePanel />;
        }
    };
    
    return (
        <div className="w-full h-full bg-mac-gray flex">
            <aside className="w-56 h-full bg-mac-gray-header/60 p-3 shrink-0 border-r border-black/10">
                <div className="space-y-1">
                    <SidebarItem icon="🎨" label="Appearance" isActive={activePanel === 'Appearance'} onClick={() => setActivePanel('Appearance')} />
                    <SidebarItem icon="📏" label="Dock & Menu Bar" isActive={activePanel === 'Dock & Menu Bar'} onClick={() => setActivePanel('Dock & Menu Bar')} />
                    <SidebarItem icon="🔒" label="Privacy & Security" isActive={activePanel === 'Privacy & Security'} onClick={() => setActivePanel('Privacy & Security')} />
                    <SidebarItem icon="💬" label="Aura Assistant" isActive={activePanel === 'Aura Assistant'} onClick={() => setActivePanel('Aura Assistant')} />
                    <SidebarItem icon="👤" label="Users & Accounts" isActive={activePanel === 'Users & Accounts'} onClick={() => setActivePanel('Users & Accounts')} />
                    <SidebarItem icon="ℹ️" label="About" isActive={activePanel === 'About'} onClick={() => setActivePanel('About')} />
                </div>
            </aside>
            <main className="flex-grow p-8 overflow-y-auto">
                {renderPanel()}
            </main>
        </div>
    );
};
