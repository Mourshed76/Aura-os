import React, { useState, useEffect } from 'react';

export const Clock: React.FC = () => {
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const timerId = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timerId);
    }, []);

    return (
        <div className="text-sm font-medium tracking-wide">
            <span>{time.toLocaleDateString([], { weekday: 'short' })} </span>
            <span>{time.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span>
        </div>
    );
};
