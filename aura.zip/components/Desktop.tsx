import React from 'react';
import type { AppDefinition } from '../types';
import { APPS } from '../constants';
import { useSettings } from '../context/SettingsContext';

interface DesktopProps {
    onOpenApp: (app: AppDefinition) => void;
}

const DesktopIcon: React.FC<{ app: AppDefinition; onOpen: (app: AppDefinition) => void }> = ({ app, onOpen }) => (
    <div
        className="flex flex-col items-center justify-center space-y-1 text-center p-2 rounded-lg hover:bg-black/10 transition-colors duration-200 cursor-pointer w-24"
        onDoubleClick={() => onOpen(app)}
        aria-label={`Open ${app.name}`}
    >
        <div className="w-16 h-16 drop-shadow-lg">{app.icon}</div>
        <span 
          className="text-white text-sm font-medium select-none px-2 py-0.5 rounded-md"
          style={{ textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}
        >
          {app.name}
        </span>
    </div>
);

export const Desktop: React.FC<DesktopProps> = ({ onOpenApp }) => {
    const { installedApps } = useSettings();
    const desktopApps = APPS.filter(app => app.isDesktopShortcut && installedApps.includes(app.id));

    return (
        <div className="absolute inset-0 pt-8">
            <div className="absolute top-10 left-5 grid grid-cols-1 gap-1">
                {desktopApps.map(app => (
                    <DesktopIcon key={app.id} app={app} onOpen={onOpenApp} />
                ))}
            </div>
        </div>
    );
};