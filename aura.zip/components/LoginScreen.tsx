import React, { useState } from 'react';
import { useSettings } from '../context/SettingsContext';
import { OS_NAME, WALLPAPERS } from '../constants';

export const LoginScreen: React.FC = () => {
    const { login } = useSettings();
    const [name, setName] = useState('Aura User');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        login(name);
    };
    
    const defaultWallpaper = WALLPAPERS[0].url;

    return (
        <div 
            className="w-screen h-screen flex items-center justify-center bg-cover bg-center"
            style={{ backgroundImage: `url(${defaultWallpaper})` }}
        >
            <div className="absolute inset-0 bg-black/20 backdrop-blur-xl"></div>
            <div className="relative flex flex-col items-center text-center p-12 bg-white/10 backdrop-blur-2xl rounded-2xl shadow-2xl border border-white/20">
                <div className="text-8xl mb-4 animate-pulse">✨</div>
                <h1 className="text-4xl font-bold text-white" style={{ textShadow: '0 2px 5px rgba(0,0,0,0.5)' }}>Welcome to {OS_NAME}</h1>
                <p className="text-white/80 mt-2">Please enter your name to continue</p>
                <form onSubmit={handleSubmit} className="mt-8 flex flex-col items-center w-full max-w-xs">
                    <input 
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full px-4 py-3 bg-white/20 text-white placeholder-white/60 text-center rounded-lg border border-white/30 focus:ring-2 focus:ring-white/50 focus:outline-none"
                        placeholder="Enter your name"
                    />
                    <button 
                        type="submit"
                        className="mt-4 w-full px-4 py-3 bg-white/90 hover:bg-white text-black font-bold rounded-lg transition-colors"
                    >
                        Log In
                    </button>
                </form>
            </div>
        </div>
    );
};