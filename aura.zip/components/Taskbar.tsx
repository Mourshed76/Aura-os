import React, { useState, useMemo } from 'react';
import type { AppDefinition, WindowInstance } from '../types';
import { APPS } from '../constants';
import { useSettings } from '../context/SettingsContext';

interface DockProps {
    windows: WindowInstance[];
    onToggleMinimize: (id: string) => void;
    onFocus: (id: string) => void;
    onLaunchpadClick: () => void;
    activeWindowId: string | null;
    onOpenApp: (app: AppDefinition) => void;
    isFullScreenMode?: boolean;
    isVisible?: boolean;
}

const LaunchpadIconFC = () => (
    <div className="w-full h-full rounded-[22%] bg-gray-700 grid grid-cols-3 grid-rows-3 p-[10%] gap-[5%]">
        {[...Array(9)].map((_, i) => (
            <div key={i} className={`rounded-full ${['bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-purple-500', 'bg-pink-500', 'bg-orange-500', 'bg-indigo-500', 'bg-teal-500'][i]}`}></div>
        ))}
    </div>
);

const DockIcon: React.FC<{
    app: AppDefinition;
    onClick: () => void;
    isRunning: boolean;
}> = ({ app, onClick, isRunning }) => {
    const { dockSize, dockMagnification } = useSettings();
    const [isHovered, setIsHovered] = useState(false);

    const iconStyle = {
        width: `${dockSize}px`,
        height: `${dockSize}px`,
        transition: 'transform 0.15s cubic-bezier(0.4, 0, 0.2, 1)',
        transform: isHovered ? `scale(${dockMagnification}) translateY(-10px)` : 'scale(1) translateY(0)',
    };
    
    return (
        <div 
            className="flex flex-col items-center relative cursor-pointer" 
            onClick={onClick}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
        >
            <div
                style={iconStyle}
                className="p-1 drop-shadow-lg"
                aria-label={app.name}
            >
                {app.icon}
            </div>
            {isRunning && <div className="absolute bottom-0 w-1.5 h-1.5 bg-white/80 rounded-full mb-0.5"></div>}
            <div 
                className={`absolute bottom-full mb-3 px-3 py-1.5 bg-black/70 text-white text-sm rounded-md shadow-lg backdrop-blur-sm pointer-events-none transition-opacity duration-150 ${isHovered ? 'opacity-100' : 'opacity-0'}`}
            >
                {app.name}
            </div>
        </div>
    );
};

export const Dock: React.FC<DockProps> = ({ windows, onToggleMinimize, onFocus, onLaunchpadClick, activeWindowId, onOpenApp, isFullScreenMode = false, isVisible = true }) => {
    const { dockSize, installedApps } = useSettings();
    
    const dockApps = useMemo(() => {
        const openAppIds = new Set(windows.map(win => win.appId));
        const pinnedAndOpenApps = APPS.filter(app => 
            (app.isPinned || openAppIds.has(app.id)) && installedApps.includes(app.id)
        );
        const sortedApps = [...pinnedAndOpenApps].sort((a, b) => {
            const aIsPinned = a.isPinned ?? false;
            const bIsPinned = b.isPinned ?? false;
            if (aIsPinned && !bIsPinned) return -1;
            if (!aIsPinned && bIsPinned) return 1;
            return 0;
        });
        return sortedApps.filter((app, index, self) => 
            index === self.findIndex((t) => (t.id === app.id))
        );
    }, [windows, installedApps]);
    
    const handleIconClick = (app: AppDefinition) => {
        const window = windows.find(w => w.appId === app.id);
        if (window) {
            if (activeWindowId === window.id && !window.isMinimized) {
                onToggleMinimize(window.id);
            } else {
                if(window.isMinimized) {
                    onToggleMinimize(window.id);
                }
                onFocus(window.id);
            }
        } else {
            onOpenApp(app);
        }
    };

    return (
        <footer className={`fixed bottom-2 left-0 right-0 h-24 flex justify-center items-end z-[1000] pointer-events-none transition-transform duration-300 ease-in-out ${isFullScreenMode ? (isVisible ? 'translate-y-0' : 'translate-y-[120%]') : ''}`}>
            <div 
                className="flex items-end space-x-2 bg-white/20 backdrop-blur-xl p-2 rounded-2xl shadow-2xl border border-white/30 pointer-events-auto"
                style={{ height: `${dockSize + 16}px` }}
            >
                <DockIcon 
                    app={{ id: 'launchpad', name: 'Launchpad', icon: <LaunchpadIconFC />, component: () => null, category: 'System', description: '', sizeMB: 0 }}
                    onClick={onLaunchpadClick}
                    isRunning={false}
                />

                {dockApps.map(app => {
                    const win = windows.find(w => w.appId === app.id);
                    return (
                        <DockIcon
                            key={app.id}
                            app={app}
                            onClick={() => handleIconClick(app)}
                            isRunning={!!win}
                        />
                    );
                })}
            </div>
        </footer>
    );
};