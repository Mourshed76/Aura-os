import React, { useRef, useCallback } from 'react';
import type { WindowInstance, OSAction } from '../types';

interface WindowProps {
    instance: WindowInstance;
    onClose: (id: string) => void;
    onMinimize: (id: string) => void;
    onMaximize: (id: string) => void;
    onToggleFullScreen: (id: string) => void;
    onFocus: (id: string) => void;
    onPositionChange: (id: string, x: number, y: number) => void;
    onSizeChange: (id: string, width: number, height: number) => void;
    isActive: boolean;
    onExecuteAction: (action: OSAction) => void;
}

const WindowControls: React.FC<{ onMinimize: () => void; onClose: () => void; onToggleFullScreen: () => void; }> = ({ onMinimize, onClose, onToggleFullScreen }) => (
    <div className="flex items-center space-x-2">
        <button onClick={onClose} className="w-3.5 h-3.5 rounded-full bg-red-500 hover:bg-red-600 focus:outline-none border border-red-700/50"></button>
        <button onClick={onMinimize} className="w-3.5 h-3.5 rounded-full bg-yellow-500 hover:bg-yellow-600 focus:outline-none border border-yellow-700/50"></button>
        <button onClick={onToggleFullScreen} className="w-3.5 h-3.5 rounded-full bg-green-500 hover:bg-green-600 focus:outline-none border border-green-700/50"></button>
    </div>
);

type ResizeDirection = 'n' | 's' | 'e' | 'w' | 'ne' | 'nw' | 'se' | 'sw';

export const Window: React.FC<WindowProps> = ({
    instance,
    onClose,
    onMinimize,
    onMaximize,
    onToggleFullScreen,
    onFocus,
    onPositionChange,
    onSizeChange,
    isActive,
    onExecuteAction,
}) => {
    const dragRef = useRef({ x: 0, y: 0 });
    const resizeRef = useRef({
        startX: 0,
        startY: 0,
        startWidth: 0,
        startHeight: 0,
        startWindowX: 0,
        startWindowY: 0,
        direction: '' as ResizeDirection | '',
    });

    const handleDragStart = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        if (instance.isMaximized || instance.isFullScreen) return;
        onFocus(instance.id);
        dragRef.current = {
            x: e.clientX - instance.x,
            y: e.clientY - instance.y,
        };
        document.addEventListener('mousemove', handleDragMove);
        document.addEventListener('mouseup', handleDragEnd);
    }, [instance.isMaximized, instance.isFullScreen, instance.x, instance.y, instance.id, onFocus]);

    const handleDragMove = useCallback((e: MouseEvent) => {
        if (instance.isMaximized || instance.isFullScreen) return;
        let newX = e.clientX - dragRef.current.x;
        let newY = e.clientY - dragRef.current.y;
        
        const menuBarHeight = 28;
        if (newY < menuBarHeight) newY = menuBarHeight;

        onPositionChange(instance.id, newX, newY);
    }, [instance.id, instance.isMaximized, instance.isFullScreen, onPositionChange]);

    const handleDragEnd = useCallback(() => {
        document.removeEventListener('mousemove', handleDragMove);
        document.removeEventListener('mouseup', handleDragEnd);
    }, [handleDragMove]);
    
    const handleResizeMove = useCallback((e: MouseEvent) => {
        if (instance.isMaximized || instance.isFullScreen) return;
        
        const { startX, startY, startWidth, startHeight, startWindowX, startWindowY, direction } = resizeRef.current;
        let newWidth = startWidth;
        let newHeight = startHeight;
        let newX = startWindowX;
        let newY = startWindowY;

        const deltaX = e.clientX - startX;
        const deltaY = e.clientY - startY;

        if (direction.includes('e')) newWidth = startWidth + deltaX;
        if (direction.includes('s')) newHeight = startHeight + deltaY;
        if (direction.includes('w')) {
            newWidth = startWidth - deltaX;
            newX = startWindowX + deltaX;
        }
        if (direction.includes('n')) {
            newHeight = startHeight - deltaY;
            newY = startWindowY + deltaY;
        }

        const minWidth = 300;
        const minHeight = 200;

        if (newWidth < minWidth) {
            if(direction.includes('w')) newX = startWindowX + startWidth - minWidth;
            newWidth = minWidth;
        }
        if (newHeight < minHeight) {
            if(direction.includes('n')) newY = startWindowY + startHeight - minHeight;
            newHeight = minHeight;
        }

        onPositionChange(instance.id, newX, newY);
        onSizeChange(instance.id, newWidth, newHeight);

    }, [instance.id, instance.isMaximized, instance.isFullScreen, onSizeChange, onPositionChange]);

    const handleResizeEnd = useCallback(() => {
        document.removeEventListener('mousemove', handleResizeMove);
        document.removeEventListener('mouseup', handleResizeEnd);
    }, [handleResizeMove]);
    
    const handleResizeStart = useCallback((e: React.MouseEvent<HTMLDivElement>, direction: ResizeDirection) => {
        if (instance.isMaximized || instance.isFullScreen) return;
        e.stopPropagation();
        onFocus(instance.id);
        resizeRef.current = {
            startX: e.clientX,
            startY: e.clientY,
            startWidth: instance.width,
            startHeight: instance.height,
            startWindowX: instance.x,
            startWindowY: instance.y,
            direction: direction,
        };
        document.addEventListener('mousemove', handleResizeMove);
        document.addEventListener('mouseup', handleResizeEnd);
    }, [instance.isMaximized, instance.isFullScreen, instance.id, onFocus, instance.width, instance.height, instance.x, instance.y, handleResizeMove, handleResizeEnd]);
    
    const AppContent = instance.component;

    const getWindowStyle = () => {
        if (instance.isFullScreen) {
            return {
                top: 0, left: 0, width: '100vw', height: '100vh',
                borderRadius: 0,
                transition: 'none',
            };
        }
        if (instance.isMaximized) {
             return {
                top: '28px',
                left: '0px',
                width: '100vw',
                height: 'calc(100vh - 28px - 96px)', // Screen height - menubar - dock
                borderRadius: '0',
                transition: 'top 0.2s ease-out, left 0.2s ease-out, width 0.2s ease-out, height 0.2s ease-out',
            };
        }
        return {
            top: instance.y,
            left: instance.x,
            width: instance.width,
            height: instance.height,
        };
    };
    
    const resizeHandles: {direction: ResizeDirection, className: string}[] = [
        { direction: 'n', className: 'cursor-n-resize top-0 left-1/2 -translate-x-1/2 h-2 w-full' },
        { direction: 's', className: 'cursor-s-resize bottom-0 left-1/2 -translate-x-1/2 h-2 w-full' },
        { direction: 'w', className: 'cursor-w-resize top-1/2 -translate-y-1/2 left-0 w-2 h-full' },
        { direction: 'e', className: 'cursor-e-resize top-1/2 -translate-y-1/2 right-0 w-2 h-full' },
        { direction: 'nw', className: 'cursor-nw-resize top-0 left-0 h-4 w-4' },
        { direction: 'ne', className: 'cursor-ne-resize top-0 right-0 h-4 w-4' },
        { direction: 'sw', className: 'cursor-sw-resize bottom-0 left-0 h-4 w-4' },
        { direction: 'se', className: 'cursor-se-resize bottom-0 right-0 h-4 w-4' },
    ];
    
    return (
        <div
            className={`absolute flex flex-col bg-mac-gray shadow-2xl overflow-hidden border
                ${isActive ? 'border-black/20 shadow-blue-500/30' : 'border-black/20 shadow-black/30'}
                ${instance.isMaximized || instance.isFullScreen ? '' : 'rounded-lg'}`
            }
            style={{
                ...getWindowStyle(),
                zIndex: instance.isFullScreen ? 2500 : instance.zIndex,
                opacity: instance.isMinimized ? 0 : 1,
                transform: instance.isMinimized ? 'scale(0.9)' : 'scale(1)',
                transition: `opacity 0.2s ease-out, transform 0.2s ease-out ${!instance.isMaximized && !instance.isFullScreen ? ', top 0s, left 0s, width 0s, height 0s' : ''}`,
            }}
            onMouseDown={() => !instance.isFullScreen && onFocus(instance.id)}
        >
            <header
                className={`h-9 bg-mac-gray-header/80 backdrop-blur-xl flex items-center justify-center px-4 text-mac-text relative shrink-0 border-b border-black/10 ${!instance.isMaximized && !instance.isFullScreen ? 'cursor-move' : ''}`}
                onMouseDown={handleDragStart}
                onDoubleClick={() => onMaximize(instance.id)}
            >
                <div className="absolute left-3 top-1/2 -translate-y-1/2">
                  <WindowControls
                      onMinimize={() => onMinimize(instance.id)}
                      onClose={() => onClose(instance.id)}
                      onToggleFullScreen={() => onToggleFullScreen(instance.id)}
                  />
                </div>
                <span className="text-sm font-semibold select-none">{instance.title}</span>
            </header>
            <main className="flex-grow bg-mac-gray overflow-auto">
                <AppContent windowId={instance.id} onExecuteAction={onExecuteAction}/>
            </main>
             {!instance.isMaximized && !instance.isFullScreen && resizeHandles.map(handle => (
                <div
                    key={handle.direction}
                    className={`absolute z-10 ${handle.className}`}
                    onMouseDown={(e) => handleResizeStart(e, handle.direction)}
                />
            ))}
        </div>
    );
};