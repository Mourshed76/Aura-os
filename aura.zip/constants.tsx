import React from 'react';
import type { AppDefinition } from './types';
import { FinderApp } from './apps/system/Finder';
import { AuraApp } from './apps/system/Aura';
import { NotesApp } from './apps/productivity/Notes';
import { PhotosApp } from './apps/entertainment/Photos';
import { AppStoreApp } from './apps/system/AppStore';
import { SettingsApp } from './apps/system/Settings';
import { BrowserApp } from './apps/system/Browser';
import { CalendarApp } from './apps/productivity/Calendar';
import { MailApp } from './apps/productivity/Mail';
import { MusicApp } from './apps/entertainment/Music';
import { ChessApp } from './apps/games/Chess';
import { CalculatorApp } from './apps/productivity/Calculator';
import { SnakeApp } from './apps/games/Snake';
import { TicTacToeApp } from './apps/games/TicTacToe';
import { PongApp } from './apps/games/Pong';
import { BrickBreakerApp } from './apps/games/BrickBreaker';


export const OS_NAME = "Aura";

export const WALLPAPERS = [
    { name: 'Aura Default', url: 'https://picsum.photos/seed/aura/1920/1080' },
    { name: 'Crimson Vista', url: 'https://picsum.photos/seed/vista/1920/1080' },
    { name: 'Azure Dream', url: 'https://picsum.photos/seed/dream/1920/1080' },
    { name: 'Emerald Peak', url: 'https://picsum.photos/seed/peak/1920/1080' },
    { name: 'Golden Dune', url: 'https://picsum.photos/seed/dune/1920/1080' },
    { name: 'Violet Night', url: 'https://picsum.photos/seed/night/1920/1080' },
];

// macOS-style Icons
const FinderIcon = () => (
    <svg viewBox="0 0 1024 1024" className="w-full h-full"><path d="M857.1 292.1c-4.2-11.4-14.3-19-26.6-19h-184c-13.2 0-24.5 9.1-27.2 21.6L512 800h371.7c13.4 0 25.2-9.4 27-22.5L857.1 292.1z" fill="#00A7F7"></path><path d="M492.4 294.6c-2.7-12.5-14-21.6-27.2-21.6h-184c-12.3 0-22.4 7.6-26.6 19L102.3 777.5c-1.8 13.1 10 24.5 23.4 24.5H512L492.4 294.6z" fill="#0079F7"></path><path d="M683.4 294.6L790.6 800H512L683.4 294.6z" fill="#0057D9"></path><path d="M512 800h-3.5L512 273.1 619.2 800H512z" fill="#00A7F7"></path><path d="M512 273.1c-13.4 0-13.4 0 0 0z" fill="#00C9F7"></path><path d="M640 457.1c0 70.7-57.3 128-128 128s-128-57.3-128-128 57.3-128 128-128 128 57.3 128 128z" fill="#383838"></path><path d="M621.7 457.1c0 61.7-50 111.7-111.7 111.7s-111.7-50-111.7-111.7 50-111.7 111.7-111.7 111.7 50 111.7 111.7z" fill="#545454"></path><path d="M512 562.2c-58.1 0-105.1-47-105.1-105.1S453.9 352 512 352s105.1 47 105.1 105.1-47.1 105.1-105.1 105.1z" fill="#383838"></path><path d="M448 457.1c0 35.3 28.7 64 64 64V393.1c-35.3 0-64 28.7-64 64z" fill="#00A7F7"></path><path d="M512 521.1c35.3 0 64-28.7 64-64h-64v64z" fill="#0079F7"></path><path d="M576 457.1c0-35.3-28.7-64-64-64v128c35.3 0 64-28.7 64-64z" fill="#0057D9"></path><path d="M470.9 416c-11.8 11.8-11.8 30.8 0 42.5 11.8 11.8 30.8 11.8 42.5 0 11.8-11.8 11.8-30.8 0-42.5-11.7-11.7-30.7-11.7-42.5 0z" fill="#FFFFFF"></path></svg>
);

const AuraIcon = () => (
    <svg viewBox="0 0 100 100" className="w-full h-full"><radialGradient id="a" cx="33.84" cy="133.74" r="77.93" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#28c4f0"></stop><stop offset=".24" stop-color="#21bade"></stop><stop offset=".62" stop-color="#14a3be"></stop><stop offset=".88" stop-color="#0e97ab"></stop><stop offset="1" stop-color="#0c94a6"></stop></radialGradient><radialGradient id="b" cx="66.16" cy="133.74" r="77.93" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#d4349c"></stop><stop offset=".3" stop-color="#c93399"></stop><stop offset=".71" stop-color="#b23192"></stop><stop offset="1" stop-color="#a5308e"></stop></radialGradient><radialGradient id="c" cx="49.33" cy="116.03" r="79.91" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#a5308e"></stop><stop offset=".35" stop-color="#792e92"></stop><stop offset=".65" stop-color="#562c96"></stop><stop offset="1" stop-color="#3b2b99"></stop></radialGradient><circle cx="50" cy="50" r="45" fill="#1e1e1e"></circle><path fill="url(#a)" d="M72.5,50A22.5,22.5,0,0,1,50,72.5V50Z"></path><path fill="url(#b)" d="M50,27.5A22.5,22.5,0,0,1,72.5,50H50Z"></path><path fill="url(#c)" d="M27.5,50A22.5,22.5,0,0,1,50,27.5V50Z"></path><path fill="#0c94a6" d="M50,72.5A22.5,22.5,0,0,1,27.5,50H50Z"></path></svg>
);

const NotesIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-white shadow-md flex flex-col overflow-hidden">
        <div className="h-[20%] bg-[#f7d55f]"></div>
        <div className="flex-grow bg-[#fff] p-[10%] space-y-[10%]">
            <div className="w-full h-[8%] bg-gray-300 rounded-sm"></div>
            <div className="w-[80%] h-[8%] bg-gray-300 rounded-sm"></div>
            <div className="w-full h-[8%] bg-gray-300 rounded-sm"></div>
        </div>
    </div>
);

const PhotosIcon = () => (
    <div className="w-full h-full flex items-center justify-center rounded-[22%] bg-white">
        <div className="relative w-[80%] h-[80%]">
             <svg viewBox="0 0 1024 1024" className="w-full h-full"><path d="M512 1024q-138.857 0-261.143-55.543t-210.857-150.857-150.857-210.857-55.543-261.143 55.543-261.143 150.857-210.857 210.857-150.857 261.143-55.543 261.143 55.543 210.857 150.857 150.857 210.857 55.543 261.143-55.543 261.143-150.857 210.857-210.857 150.857-261.143 55.543z" fill="#ffbd2e"></path><path d="M864 512q0-34.286-13.714-72.571t-36.571-70.286-56-61.143-70.286-44.571-78.286-21.143-78.286 21.143-70.286 44.571-56 61.143-36.571 70.286-13.714 72.571q0 34.286 13.714 72.571t36.571 70.286 56 61.143 70.286 44.571 78.286 21.143 78.286-21.143 70.286-44.571 56-61.143 36.571-70.286 13.714-72.571z" fill="#fff7e0"></path><path d="M512 1024q-212.571 0-362.286-149.714t-149.714-362.286 149.714-362.286 362.286-149.714 362.286 149.714 149.714 362.286-149.714 362.286-362.286 149.714z m0-822.857q-179.429 0-305.143 125.714t-125.714 305.143 125.714 305.143 305.143 125.714 305.143-125.714 125.714-305.143-125.714-305.143-305.143-125.714z" fill="#ff5e00"></path><path d="M950.857 512q0-34.286-13.714-72.571t-36.571-70.286-56-61.143-70.286-44.571-78.286-21.143-78.286 21.143-70.286 44.571-56 61.143-36.571 70.286-13.714 72.571q0 34.286 13.714 72.571t36.571 70.286 56 61.143 70.286 44.571 78.286 21.143 78.286-21.143 70.286-44.571 56-61.143 36.571-70.286 13.714-72.571z" fill="#ffac33"></path><path d="M950.857 512q0 73.143-26.286 142.857t-72.571 122.286-109.143 89.143-131.429 44.571-135.429-10.286-122.286-55.543-96-89.143-59.429-109.143-22.857-113.143 22.857-113.143 59.429-109.143 96-89.143 122.286-55.543 135.429-10.286 131.429 44.571 109.143 89.143 72.571 122.286 26.286 142.857z" fill="#ffd54f"></path><path d="M907.429 512q0-62.857-22.857-122.286t-62.286-104.571-93.714-76.571-113.143-38.286-116.571 9.714-104.571 48-82.286 76.571-51.429 93.714-19.429 96.571 19.429 96.571 51.429 93.714 82.286 76.571 104.571 48 116.571 9.714 113.143-38.286 93.714-76.571 62.286-104.571 22.857-122.286z" fill="#fffde7"></path><path d="M512 512m-91.429 0q0-38.286 26.857-65.143t64.571-26.857 64.571 26.857 26.857 65.143-26.857 65.143-64.571 26.857-64.571-26.857-26.857-65.143z" fill="#ff8f00"></path></svg>
        </div>
    </div>
);

const AppStoreIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-[#1a7efb] flex items-center justify-center">
        <div className="relative w-1/2 h-1/2">
            <div className="absolute w-full h-1 bg-white rounded-full top-1/2 -mt-0.5" style={{ transform: 'rotate(45deg)'}}></div>
            <div className="absolute w-full h-1 bg-white rounded-full top-1/2 -mt-0.5" style={{ transform: 'rotate(-45deg)'}}></div>
            <div className="absolute w-1 h-full bg-white rounded-full left-1/2 -ml-0.5"></div>
        </div>
    </div>
);

const SettingsIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center shadow-md">
        <div className="relative w-[70%] h-[70%]">
             <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M14.8341 19.3413L15.2536 15.2952C15.932 14.9961 16.5621 14.595 17.1189 14.1189L21.0118 15.6881L23.4996 11.5L19.9881 8.84301C20.0383 8.42398 20.0383 7.98976 19.9881 7.57073L23.4996 4.91375L21.0118 0.725513L17.1189 2.2947C16.5621 1.81864 15.932 1.41753 15.2536 1.1184L14.8341 -3.05176e-05H9.98818L9.56865 4.0461C8.8902 4.34522 8.26007 4.74633 7.70331 5.22239L3.81041 3.65318L1.3226 8L4.83411 10.657C4.78393 11.076 4.78393 11.5103 4.83411 11.9293L1.3226 14.5862L3.81041 18.7745L7.70331 17.2053C8.26007 17.6814 8.8902 18.0825 9.56865 18.3816L9.98818 22.4277H14.8341V19.3413Z" fill="#8A95A1"/>
                <circle cx="12.4114" cy="11.2137" r="3.73134" fill="#6C757D"/>
                <circle cx="12.4114" cy="11.2137" r="1.86567" fill="#ADB5BD"/>
            </svg>
        </div>
    </div>
);

const BrowserIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-white flex items-center justify-center shadow-md">
        <div className="w-[75%] h-[75%]">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="50" r="45" stroke="url(#g_paint0_radial_1_2)" strokeWidth="10"/>
                <circle cx="50" cy="50" r="30" stroke="url(#g_paint1_radial_1_2)" strokeWidth="4"/>
                <defs>
                <radialGradient id="g_paint0_radial_1_2" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(50 50) rotate(90) scale(50)">
                    <stop stopColor="#00A7F7"/>
                    <stop offset="1" stopColor="#0057D9"/>
                </radialGradient>
                <radialGradient id="g_paint1_radial_1_2" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(50 50) rotate(90) scale(32)">
                    <stop stopColor="#84FAB0"/>
                    <stop offset="1" stopColor="#8FD3F4"/>
                </radialGradient>
                </defs>
            </svg>
        </div>
    </div>
);

const MailIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-[#42a5f5] flex items-center justify-center shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-3/4 h-3/4 text-white" viewBox="0 0 24 24" fill="currentColor">
            <path d="M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6zm-2 0l-8 5-8-5h16zm0 12H4V8l8 5 8-5v10z"/>
        </svg>
    </div>
);

const CalendarIcon = () => (
     <div className="w-full h-full rounded-[22%] bg-white shadow-md flex flex-col items-center justify-center text-center overflow-hidden">
        <div className="w-full bg-red-500 text-white font-bold text-[25%] py-[2%]">
            JUL
        </div>
        <div className="text-black font-bold text-[60%] leading-none">
            24
        </div>
    </div>
);

const MusicIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-gradient-to-br from-pink-500 to-orange-400 flex items-center justify-center shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-3/5 h-3/5 text-white" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
        </svg>
    </div>
);

const ChessIcon = () => (
     <div className="w-full h-full rounded-[22%] bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-3/5 h-3/5 text-white" viewBox="0 0 24 24" fill="currentColor">
            <path d="M20 2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM4 18V4h16v14H4z"/><path d="M12 14.5c-1 0-1.85-.5-2.4-1.33-.28-.42-.72-1.3-.72-1.33 0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5c0 .03-.44.91-.72 1.33-.55.83-1.4 1.33-2.4 1.33zM12 6c-1.63 0-3.06.79-3.98 2H12V6zm0 0v2h3.98C15.06 6.79 13.63 6 12 6z"/>
        </svg>
    </div>
);

const RemindersIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-white flex items-center justify-center shadow-md p-2.5">
        <div className="w-full h-full flex flex-col space-y-1.5">
            <div className="flex items-center space-x-2"><div className="w-3 h-3 rounded-full border-2 border-orange-500"></div><div className="w-full h-2 bg-gray-300 rounded-full"></div></div>
            <div className="flex items-center space-x-2"><div className="w-3 h-3 rounded-full border-2 border-blue-500"></div><div className="w-4/5 h-2 bg-gray-300 rounded-full"></div></div>
            <div className="flex items-center space-x-2"><div className="w-3 h-3 rounded-full border-2 border-gray-400"></div><div className="w-full h-2 bg-gray-300 rounded-full"></div></div>
        </div>
    </div>
);

const TVIcon = () => (
     <div className="w-full h-full rounded-[22%] bg-gray-900 flex items-center justify-center shadow-md">
        <div className="w-full h-3/5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
    </div>
);

const CalculatorIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-gray-200 flex items-center justify-center shadow-md text-3xl font-bold text-gray-800">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-3/5 h-3/5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 14h.01M12 17h.01M15 17h.01M4 7a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H6a2 2 0 01-2-2V7z" />
        </svg>
    </div>
);

const SnakeIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-green-500 flex items-center justify-center shadow-md p-2">
        <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4/5 h-4/5">
            <path d="M7.5 2a2.5 2.5 0 0 0-2.5 2.5v15a2.5 2.5 0 0 0 5 0V17a2.5 2.5 0 0 1 5 0v2.5a2.5 2.5 0 0 0 5 0V4.5a2.5 2.5 0 0 0-5 0v2.5a2.5 2.5 0 0 1-5 0V4.5A2.5 2.5 0 0 0 7.5 2z"/>
        </svg>
    </div>
);

const TicTacToeIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-gray-200 flex items-center justify-center shadow-md p-2">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-4/5 h-4/5 text-gray-700">
            <line x1="4" y1="4" x2="20" y2="20"></line>
            <line x1="20" y1="4" x2="4" y2="20"></line>
            <circle cx="12" cy="12" r="3"></circle>
        </svg>
    </div>
);

const PongIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-black flex items-center justify-center shadow-md p-2.5">
        <div className="w-full h-full relative">
            <div className="absolute w-1 h-1/4 bg-white top-1/4 left-1"></div>
            <div className="absolute w-1 h-1/4 bg-white bottom-1/4 right-1"></div>
            <div className="absolute w-1.5 h-1.5 bg-white rounded-full top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
        </div>
    </div>
);

const BrickBreakerIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-gray-800 flex items-center justify-center shadow-md p-3">
        <div className="w-full h-full grid grid-cols-3 grid-rows-2 gap-1">
            <div className="bg-pink-500 rounded-sm"></div>
            <div className="bg-purple-500 rounded-sm"></div>
            <div className="bg-indigo-500 rounded-sm"></div>
            <div className="bg-blue-500 rounded-sm col-span-2"></div>
            <div className="bg-cyan-500 rounded-sm"></div>
        </div>
    </div>
);


export const APPS: AppDefinition[] = [
    {
        id: 'finder',
        name: 'Finder',
        icon: <FinderIcon />,
        component: FinderApp,
        defaultSize: { width: 700, height: 500 },
        description: 'File and system navigation.',
        category: 'System',
        isPinned: true,
        sizeMB: 1.2,
    },
    {
        id: 'aura_chat',
        name: 'Aura',
        icon: <AuraIcon />,
        component: AuraApp,
        defaultSize: { width: 500, height: 650 },
        description: 'Chat with Aura, your intelligent AGI assistant.',
        category: 'System',
        isPinned: true,
        sizeMB: 25.6,
    },
    {
        id: 'browser',
        name: 'Nexus Browser',
        icon: <BrowserIcon />,
        component: BrowserApp,
        defaultSize: { width: 1024, height: 768 },
        description: 'A new way to browse the web with AI.',
        category: 'System',
        isDesktopShortcut: true,
        isPinned: true,
        sizeMB: 32.1,
    },
    {
        id: 'app_store',
        name: 'App Store',
        icon: <AppStoreIcon />,
        component: AppStoreApp,
        defaultSize: { width: 900, height: 700 },
        description: 'Discover and install new apps for your OS.',
        category: 'System',
        isPinned: true,
        sizeMB: 15.8,
    },
    {
        id: 'settings',
        name: 'System Settings',
        icon: <SettingsIcon />,
        component: SettingsApp,
        defaultSize: { width: 750, height: 550 },
        description: 'Configure system settings and preferences.',
        category: 'System',
        isPinned: true,
        sizeMB: 8.4,
    },
    {
        id: 'notes',
        name: 'Notes',
        icon: <NotesIcon />,
        component: NotesApp,
        defaultSize: { width: 600, height: 500 },
        description: 'Jot down your thoughts and ideas.',
        category: 'Productivity',
        isDesktopShortcut: true,
        sizeMB: 10.5,
    },
    {
        id: 'calculator',
        name: 'Calculator',
        icon: <CalculatorIcon />,
        component: CalculatorApp,
        defaultSize: { width: 320, height: 480 },
        description: 'Perform basic calculations.',
        category: 'Productivity',
        sizeMB: 4.3,
    },
    {
        id: 'mail',
        name: 'Mail',
        icon: <MailIcon />,
        component: MailApp,
        defaultSize: { width: 800, height: 600 },
        description: 'Connect all your email accounts.',
        category: 'Productivity',
        sizeMB: 28.9,
    },
    {
        id: 'calendar',
        name: 'Calendar',
        icon: <CalendarIcon />,
        component: CalendarApp,
        defaultSize: { width: 800, height: 600 },
        description: 'Keep track of your events and appointments.',
        category: 'Productivity',
        sizeMB: 14.2,
    },
    {
        id: 'reminders',
        name: 'Reminders',
        icon: <RemindersIcon />,
        component: CalendarApp, // Placeholder
        defaultSize: { width: 400, height: 500 },
        description: 'Manage your to-do lists.',
        category: 'Productivity',
        sizeMB: 9.7,
    },
    {
        id: 'photos',
        name: 'Photos',
        icon: <PhotosIcon />,
        component: PhotosApp,
        defaultSize: { width: 800, height: 600 },
        description: 'Browse your beautiful photo library.',
        category: 'Entertainment',
        isDesktopShortcut: true,
        sizeMB: 22.1,
    },
    {
        id: 'music',
        name: 'Music',
        icon: <MusicIcon />,
        component: MusicApp,
        defaultSize: { width: 800, height: 600 },
        description: 'Listen to your favorite songs and artists.',
        category: 'Entertainment',
        sizeMB: 18.6,
    },
    {
        id: 'tv',
        name: 'TV',
        icon: <TVIcon />,
        component: MusicApp, // Placeholder
        defaultSize: { width: 800, height: 600 },
        description: 'Watch original shows and movies.',
        category: 'Entertainment',
        sizeMB: 20.3,
    },
    {
        id: 'chess',
        name: 'Chess',
        icon: <ChessIcon />,
        component: ChessApp,
        defaultSize: { width: 400, height: 450 },
        description: 'A classic game of strategy.',
        category: 'Games',
        sizeMB: 12.5,
    },
    {
        id: 'snake',
        name: 'Snake',
        icon: <SnakeIcon />,
        component: SnakeApp,
        defaultSize: { width: 440, height: 500 },
        description: 'The classic arcade game.',
        category: 'Games',
        sizeMB: 5.1,
    },
    {
        id: 'tic_tac_toe',
        name: 'Tic-Tac-Toe',
        icon: <TicTacToeIcon />,
        component: TicTacToeApp,
        defaultSize: { width: 320, height: 420 },
        description: 'A simple strategy game.',
        category: 'Games',
        sizeMB: 3.8,
    },
    {
        id: 'pong',
        name: 'Pong',
        icon: <PongIcon />,
        component: PongApp,
        defaultSize: { width: 620, height: 480 },
        description: 'The original arcade classic.',
        category: 'Games',
        sizeMB: 4.5,
    },
    {
        id: 'brick_breaker',
        name: 'Brick Breaker',
        icon: <BrickBreakerIcon />,
        component: BrickBreakerApp,
        defaultSize: { width: 580, height: 480 },
        description: 'Break all the bricks.',
        category: 'Games',
        sizeMB: 6.2,
    },
];