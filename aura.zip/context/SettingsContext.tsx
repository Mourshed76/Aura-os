
import React, { createContext, useState, useContext, ReactNode, useMemo, useEffect } from 'react';
import { WALLPAPERS, APPS } from '../constants';

const DEFAULT_INSTALLED_APPS = ['finder', 'aura_chat', 'browser', 'app_store', 'settings', 'notes', 'photos', 'calculator'];

interface SettingsContextType {
    wallpaper: string;
    setWallpaper: (url: string) => void;
    dockSize: number;
    setDockSize: (size: number) => void;
    dockMagnification: number;
    setDockMagnification: (mag: number) => void;
    username: string | null;
    login: (name: string) => void;
    logout: () => void;
    auraChatClearCount: number;
    clearAuraChat: () => void;
    installedApps: string[];
    installingProgress: { [key: string]: number };
    installApp: (appId: string) => void;
    openApp: (appId: string) => void;
    privateAlbumPassword: string;
    setPrivateAlbumPassword: (password: string) => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // --- Appearance & Dock ---
    const [wallpaper, setWallpaper] = useState<string>(() => localStorage.getItem('aura-wallpaper') || WALLPAPERS[0].url);
    const [dockSize, setDockSize] = useState<number>(() => Number(localStorage.getItem('aura-dockSize')) || 56);
    const [dockMagnification, setDockMagnification] = useState<number>(() => Number(localStorage.getItem('aura-dockMagnification')) || 1.5);

    // --- Authentication ---
    const [username, setUsername] = useState<string | null>(() => localStorage.getItem('aura-username'));
    
    // --- App Management ---
    const [installedApps, setInstalledApps] = useState<string[]>(() => {
        const saved = localStorage.getItem('aura-installedApps');
        return saved ? JSON.parse(saved) : DEFAULT_INSTALLED_APPS;
    });
    const [installingProgress, setInstallingProgress] = useState<{ [key: string]: number }>({});

    // --- Security ---
    const [privateAlbumPassword, setPrivateAlbumPassword] = useState<string>(() => localStorage.getItem('aura-privateAlbumPassword') || '1234');


    // --- App Specific ---
    const [auraChatClearCount, setAuraChatClearCount] = useState(0);

    // --- Effects to persist settings ---
    useEffect(() => { localStorage.setItem('aura-wallpaper', wallpaper); }, [wallpaper]);
    useEffect(() => { localStorage.setItem('aura-dockSize', String(dockSize)); }, [dockSize]);
    useEffect(() => { localStorage.setItem('aura-dockMagnification', String(dockMagnification)); }, [dockMagnification]);
    useEffect(() => { localStorage.setItem('aura-privateAlbumPassword', privateAlbumPassword); }, [privateAlbumPassword]);
    useEffect(() => {
        if (username) {
            localStorage.setItem('aura-username', username);
        } else {
            localStorage.removeItem('aura-username');
        }
    }, [username]);
    useEffect(() => {
        localStorage.setItem('aura-installedApps', JSON.stringify(installedApps));
    }, [installedApps]);

    const login = (name: string) => {
        if(name.trim()) setUsername(name.trim());
    };

    const logout = () => {
        setUsername(null);
    };

    const clearAuraChat = () => {
        setAuraChatClearCount(prev => prev + 1);
    }
    
    const installApp = (appId: string) => {
        if (installedApps.includes(appId) || installingProgress[appId] !== undefined) return;

        const app = APPS.find(a => a.id === appId);
        if (!app) return;

        const installTime = (app.sizeMB || 10) * 100 + Math.random() * 500;
        const updateInterval = 50; // ms
        const totalUpdates = Math.ceil(installTime / updateInterval);
        let currentUpdate = 0;

        setInstallingProgress(prev => ({ ...prev, [appId]: 0 }));

        const intervalId = setInterval(() => {
            currentUpdate++;
            const progress = Math.min(100, Math.round((currentUpdate / totalUpdates) * 100));
            
            setInstallingProgress(prev => ({ ...prev, [appId]: progress }));

            if (currentUpdate >= totalUpdates) {
                clearInterval(intervalId);
                setInstalledApps(prev => [...prev, appId]);
                setInstallingProgress(prev => {
                    const newProgress = { ...prev };
                    delete newProgress[appId];
                    return newProgress;
                });
            }
        }, updateInterval);
    };

    // This is a placeholder for the AppStore to trigger app openings.
    const openApp = (appId: string) => {
        console.warn(`Attempted to open ${appId} from context. This should be handled by App.tsx`);
    };

    const value = useMemo(() => ({
        wallpaper,
        setWallpaper,
        dockSize,
        setDockSize,
        dockMagnification,
        setDockMagnification,
        username,
        login,
        logout,
        auraChatClearCount,
        clearAuraChat,
        installedApps,
        installingProgress,
        installApp,
        openApp,
        privateAlbumPassword,
        setPrivateAlbumPassword,
    }), [wallpaper, dockSize, dockMagnification, username, auraChatClearCount, installedApps, installingProgress, privateAlbumPassword]);

    return (
        <SettingsContext.Provider value={value}>
            {children}
        </SettingsContext.Provider>
    );
};

export const useSettings = (): SettingsContextType => {
    const context = useContext(SettingsContext);
    if (context === undefined) {
        throw new Error('useSettings must be used within a SettingsProvider');
    }
    return context;
};
