import React from 'react';

export type AppCategory = 'System' | 'Productivity' | 'Entertainment' | 'Games';

export interface OSAction {
  action: 'open_app';
  payload: {
    appId: string;
  };
}

export interface AppProps {
    windowId: string;
    onExecuteAction?: (action: OSAction) => void;
}

export interface AppDefinition {
  id: string;
  name: string;
  icon: React.ReactNode;
  component: React.ComponentType<AppProps>;
  defaultSize?: { width: number; height: number };
  description: string;
  category: AppCategory;
  isDesktopShortcut?: boolean;
  isPinned?: boolean;
  sizeMB: number;
}

export interface WindowInstance {
  id: string;
  appId: string;
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  isMinimized: boolean;
  isMaximized: boolean;
  isFullScreen: boolean;
  preMaximizedState?: { x: number, y: number, width: number, height: number };
  component: React.ComponentType<AppProps>;
  icon: React.ReactNode;
}

export interface ChecklistItem {
    id: string;
    text: string;
    completed: boolean;
}

export interface Note {
    id: string;
    title: string;
    content: string;
    updatedAt: number;
    type: 'text' | 'checklist';
}

export interface Tab {
    id: string;
    title: string;
    type: 'home' | 'webpage' | 'search';
    history: string[]; // URLs or search queries
    historyIndex: number;
    isLoading: boolean;
    favicon?: string;
}

export interface GroundingChunk {
    web: {
        uri: string;
        title: string;
    };
}

export interface SearchResult {
    summary: string;
    links: GroundingChunk[];
}

export interface Email {
  id: string;
  sender: string;
  subject: string;
  body: string;
  timestamp: number;
  isRead: boolean;
  mailbox: 'inbox' | 'sent' | 'trash';
}